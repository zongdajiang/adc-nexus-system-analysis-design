"""Render the SQLite implementation structure. Only SQLite metadata is read."""
import csv
import importlib.util
import json
import sqlite3
import sys
from pathlib import Path

out = Path(__file__).resolve().parent
delivery = out.parent
database, old_config, renderer_path = (Path(arg).resolve() for arg in sys.argv[1:])
spec = importlib.util.spec_from_file_location("relational_renderer", renderer_path)
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)
config = json.loads(old_config.read_text(encoding="utf-8-sig"))
config["project"].update(database="Java 21 JDBC · SQLite 验收结构", as_of="2026-11-09",
                         subtitle="关系数据实现模型")
config["relationship_recommendations"] = []
additions = {
    "clinical_note_signatures": (5, "病历版本签署", "记录操作账号、医师、签署时间及病历版本。"),
    "dentist_expense_allocations": (7, "医师级费用分摊", "按诊所、期间与医师保存经确认的费用归属。"),
    "followup_contact_events": (5, "复诊联系事件", "追加保存人工联系、预约关联及结束处理。"),
    "patient_followups": (5, "患者复诊建议", "保存负责医师提出的复诊建议、目标日期、联系许可和后续预约。"),
    "patient_history_versions": (2, "病史版本", "保存经询问的病史声明及后续追加版本。"),
    "request_receipts": (0, "幂等请求收据", "记录请求标识、参数摘要与可重放的业务结果。"),
    "schema_migrations": (0, "数据库迁移记录", "记录实际应用的结构迁移版本。"),
    "staff_directory": (0, "员工名册", "用于员工激活，校验机构岗位、员工编号与身份资料。"),
    "treatment_item_consents": (5, "治疗项目同意", "记录患者对指定治疗计划项目的决定及证据。"),
    "verification_challenges": (1, "验证挑战", "保存手机号或邮箱挑战、发送结果、时效、尝试和消费状态。"),
}
for name, (domain, label, description) in additions.items():
    config["domains"][domain]["tables"].append(name)
    config["table_labels"][name] = label
    config["table_descriptions"][name] = description
config["domains"][4]["tables"].remove("requested_treatment_items")
config["domains"][5]["tables"].insert(0, "requested_treatment_items")
config["table_descriptions"]["requested_treatment_items"] = (
    "关联就诊及治疗方案的拟议项目，记录顺序、数量、牙位、理由与决定状态。"
)
for rule in config["business_rules"]:
    rule["statement"] = rule["statement"].replace("SQLite/D1", "Java JDBC 实现")

with sqlite3.connect(database.as_uri() + "?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    schema = db.execute("SELECT type,name,sql FROM sqlite_master WHERE sql IS NOT NULL "
                        "AND name NOT LIKE 'sqlite_%' ORDER BY type='index',type='trigger',rowid").fetchall()
    tables = {}
    for item in schema:
        if item["type"] != "table":
            continue
        name = item["name"]
        raw = list(db.execute("SELECT * FROM pragma_table_info(?) ORDER BY cid", (name,)))
        primary_key = [r["name"] for r in sorted(raw, key=lambda r:r["pk"]) if r["pk"]]
        columns = {}
        for row in raw:
            field = {"name":row["name"], "type":row["type"], "notNull":bool(row["notnull"]),
                     "primaryKey":bool(row["pk"]) and len(primary_key) == 1}
            if row["dflt_value"] is not None:
                field["default"] = row["dflt_value"]
            columns[row["name"]] = field
        foreign = {}
        for row in db.execute("SELECT * FROM pragma_foreign_key_list(?) ORDER BY id,seq", (name,)):
            key = f"fk_{name}_{row['id']}"
            rel = foreign.setdefault(key, {"name":key, "tableTo":row["table"], "columnsFrom":[],
                "columnsTo":[], "onDelete":row["on_delete"].lower(), "onUpdate":row["on_update"].lower()})
            rel["columnsFrom"].append(row["from"])
            rel["columnsTo"].append(row["to"])
        indexes = {}
        for row in db.execute("SELECT * FROM pragma_index_list(?) WHERE origin <> 'pk' ORDER BY name", (name,)):
            index = row["name"]
            indexes[index] = {"name":index, "isUnique":bool(row["unique"]), "columns":[
                part["name"] for part in db.execute("SELECT name FROM pragma_index_info(?) ORDER BY seqno",(index,))]}
        tables[name] = {"columns":columns,"foreignKeys":foreign,"indexes":indexes,
            "compositePrimaryKeys":{"pk":{"columns":primary_key}} if len(primary_key)>1 else {}}
    assert not db.execute("PRAGMA foreign_key_check").fetchall()

snapshot = out / "sqlite-schema-snapshot.json"
snapshot.write_text(json.dumps({"tables":tables}, ensure_ascii=False, indent=2), encoding="utf8")
config_path = out / "diagram-config.json"
config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf8")
model = renderer.read_model(snapshot, config_path)
model["source"]["snapshot"] = snapshot.name
audit = renderer.validate_model(model, 71)
assert audit["passed"] and not audit["issues"], audit
assert model["counts"]["tables"] == 71 and model["counts"]["columns"] == 820 and model["counts"]["foreign_keys"] == 146
(out/"schema-model.json").write_text(json.dumps(model, ensure_ascii=False, indent=2), encoding="utf8")
(out/"结构审计.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf8")
ddl = "PRAGMA foreign_keys=ON;\n\n" + "\n\n".join(item["sql"] + ";" for item in schema) + "\n"
(out/"sqlite-schema.sql").write_text(ddl, encoding="utf8")
with sqlite3.connect(":memory:") as check:
    check.executescript(ddl)
    assert check.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0] == 71
    for name, table in tables.items():
        columns = table["columns"]
        primary_key = next(iter(table["compositePrimaryKeys"].values()), {"columns": [
            name for name, column in columns.items() if column["primaryKey"]]})["columns"]
        actual = [row[1:] for row in check.execute("SELECT * FROM pragma_table_info(?)", (name,))]
        expected = [(column["name"], column["type"], int(column["notNull"]), column.get("default"),
                     primary_key.index(column["name"]) + 1 if column["name"] in primary_key else 0)
                    for column in columns.values()]
        assert actual == expected, name
        actual_links = sorted((r[2], r[3], r[4], r[5].lower(), r[6].lower()) for r in
                              check.execute("SELECT * FROM pragma_foreign_key_list(?)", (name,)))
        expected_links = sorted((link["tableTo"], src, dst, link["onUpdate"], link["onDelete"])
                                for link in table["foreignKeys"].values()
                                for src, dst in zip(link["columnsFrom"], link["columnsTo"]))
        assert actual_links == expected_links, name
with (out/"字段字典.csv").open("w", encoding="utf-8-sig", newline="") as output:
    writer = csv.writer(output)
    writer.writerow(["业务簇","表","字段","类型","主键","是否可空","默认值","外键目标","删除动作","索引","说明"])
    for table in model["tables"]:
        for column in table["columns"]:
            links = column["fk_targets"]
            writer.writerow([table["domain_name"], table["name"], column["name"], column["type"],
                "PK" if column["pk"] else "", "是" if column["nullable"] else "否", column["default"],
                " / ".join(r["table"]+"."+r["column"] for r in links),
                " / ".join(r["on_delete"] for r in links), " / ".join(column["indexes"]), column["description"]])

plates = delivery/"assets"/"erd"/"pages"
plates.mkdir(parents=True, exist_ok=True)
renderer_dir = out/"可编辑关系图"
renderer_dir.mkdir(exist_ok=True)

def render(name, title, scene):
    renderer.render_scene_to_pdf(scene, model, plates/(name+".pdf"), title)
    renderer.render_svg(scene, model, renderer_dir/(name+".svg"), title)
    renderer.render_drawio(scene, renderer_dir/(name+".drawio"), title)
    print("Rendered", name, flush=True)

render("00_panorama", "ADC Nexus · 实施关系全景", renderer.scene_data(model, renderer.panorama_layout(model)))
for index, domain in enumerate(model["domains"], 1):
    scene = renderer.scene_data(model, renderer.domain_layout(model,domain), set(domain["tables"]))
    render(f"{index:02d}_{domain['id']}", "ADC Nexus · "+domain["name"], scene)
print(model["counts"], flush=True)
