"""Produce the review edition's changed UML models from verified role and API facts."""
import json
import subprocess
import sys
from pathlib import Path

models = Path(__file__).parent / "20261109"
models.mkdir(exist_ok=True)
output = Path(__file__).resolve().parents[2] / "assets" / "uml"
renderer = Path(sys.argv[1])


def usecases(system, actors, cases, **extra):
    return {"type":"usecase","profile":"mayuyang","ellipse_slash":True,"ellipse_width":255,
            "directed_associations":True,"association_arrow":"open","system":system,
            "actors":[{"id":key,"label":label,"face_slash":True} for key,label in actors],
            "usecases":[{"id":key,"label":label,"actors":people,"row":i}
                        for i,(key,label,people) in enumerate(cases)], **extra}


def sequence(actors, steps, activations=()):
    return {"type":"sequence","profile":"b-enterprise","frame":False,"font_size":16,
            "participants":[{"id":key,"label":label,"kind":kind} for key,label,kind in actors],
            "messages":[{"from":a,"to":b,"label":label,"kind":kind} for a,b,label,kind in steps],
            "activations":[{"participant":actor,"start_message":a,"end_message":b}
                           for actor,a,b in activations]}


overview = json.loads((models.parent/"overview/08_系统用例全景_模型.json").read_text(encoding="utf8"))
for actor in overview["actors"]:
    if actor["id"] == "patient":
        actor.update(id="manager_day", label="诊所经理")
    if actor["id"] == "user":
        actor["label"] = "内部员工"
for case in overview["usecases"]:
    if case["id"] == "UC15":
        case.update(id="UC19", label="UC-19  查看当日诊所运营", actors=["manager_day"])
    if case["id"] == "UC16":
        case["label"] = "UC-16  验证员工登录身份"

models_by_name = {
    "08_员工网页用例全景":overview,
    "21_员工账号与身份":usecases("ADC Nexus 员工网页", [("staff","诊所员工"),("admin","权限管理员")], [
        ("uc16","UC-16 验证员工登录身份",["staff"]),
        ("activate","激活员工账号",["staff"]),
        ("uc17","UC-17 管理员工密码",["staff"]),
        ("uc14","UC-14 管理账户及授权",["admin"]),
    ]),
    "17_JDBC逻辑架构":{
        "type":"layered","profile":"b-enterprise","roles":["诊所经营者","医师","前台 / 收费","总部 / 管理员"],
        "common":["同源员工网页","按实际岗位分发工作台"],
        "groups":[{"label":"身份与授权","items":["账号与会话","诊所范围","审计"]},
                  {"label":"门诊业务","items":["建档与预约","接诊与签署","复诊联系"]},
                  {"label":"经营财务","items":["开单与收退","资源管理","期间核算"]}],
        "database":"JDBC 访问 SQLite 或 PostgreSQL"},
    "25_实施部署边界":{
        "type":"deployment","profile":"b-enterprise",
        "stages":[{"id":"staff","label":"员工浏览器","kind":"client","count":1,"technology":"同源 HTML / CSS / JS"},
                  {"id":"network","label":"访问边界","kind":"internet","count":1,"technology":"本机回环 / 托管 HTTPS"},
                  {"id":"java","label":"Java 应用","kind":"server","count":1,"technology":"Java 21 / JDBC"},
                  {"id":"data","label":"关系数据库","kind":"database","count":1,"technology":"本机 SQLite / 托管 PostgreSQL"}],
        "edges":[{"from":"staff","to":"network"},{"from":"network","to":"java"},{"from":"java","to":"data"}]},
    "21_JDBC持久化职责":{
        "type":"class","profile":"b-enterprise","semantic_relationship_view":True,
        "classes":[{"id":"main","name":"Main","rank":0,"methods":["route(…): Object"]},
                   {"id":"db","name":"Db","rank":1,"methods":["read(work)","tx(work)","rows(connection, sql, args)","insert(connection, table, row)"]},
                   {"id":"schedule","name":"Scheduling","rank":1,"methods":["validate(connection, input)","create(connection, principal, input)"]}],
        "relations":[{"from":"main","to":"db","kind":"dependency","label":"事务入口"},
                     {"from":"main","to":"schedule","kind":"dependency","label":"调用预约服务"},
                     {"from":"schedule","to":"db","kind":"dependency","label":"读写记录"}]},
    "22_JDBC预约访问序列":sequence(
        [("desk","前台","actor"),("ui","预约工作台","boundary"),("main","请求处理","control"),("db","JDBC 事务","entity")],
        [("desk","ui","提交患者、项目和时段","call"),
         ("ui","main","提交预约请求","call"),
         ("main","db","开启事务，读取占用与资质","call"),
         ("db","main","授权范围、资质与资源记录","return"),
         ("main","db","写入预约和初始状态历史","call"),
         ("db","main","提交结果","return"),
         ("main","ui","返回预约编号","return"),
         ("ui","desk","展示预约结果","return")],
        [("ui",0,7),("main",1,6),("db",2,5)]),
    "36_双岗位演示序列":sequence(
        [("staff","试用者","actor"),("web","登录页","boundary"),("api","身份服务","control"),("db","关系库","entity")],
        [("staff","web","选择经营者或医师","call"),
         ("web","api","请求指定岗位演示","call"),
         ("api","db","保存对应演示账号会话","call"),
         ("db","api","会话保存结果","return"),
         ("api","web","会话 Cookie","return"),
         ("web","api","读取会话与岗位权限","call"),
         ("api","db","读取有效授权及范围","call"),
         ("db","api","角色、诊所与医师绑定","return"),
         ("api","web","会话与授权资料","return"),
         ("web","api","读取授权工作台数据","call"),
         ("api","web","返回当日运营或本人接诊数据","return"),
         ("web","staff","显示对应工作台","return")],
        [("web",0,11),("api",1,4),("api",5,8),("api",9,10),("db",2,3),("db",6,7)]),
    "37_患者小程序目标序列":sequence(
        [("patient","患者","actor"),("app","小程序","boundary"),("api","患者服务","control"),("wx","微信平台","entity")],
        [("patient","app","打开患者服务","call"),
         ("app","wx","请求临时登录凭证","call"),
         ("wx","app","临时凭证","return"),
         ("app","api","提交临时凭证","call"),
         ("api","wx","核验微信主体","call"),
         ("wx","api","返回主体标识","return"),
         ("api","app","患者会话或待绑定状态","return"),
         ("app","api","已绑定时读取本人摘要","call"),
         ("api","app","返回预约、就诊和账单","return"),
         ("app","patient","展示本人资料","return")],
        [("app",0,9),("api",3,6),("api",7,8),("wx",1,2),("wx",4,5)]),
}
models_by_name["37_患者小程序目标序列"]["fragments"] = [
    {"from":"patient","to":"api","start":7,"end":9,"operator":"opt",
     "label":"已核实绑定","operands":[{"guard":"会话绑定本人患者档案","start":7}]}
]
for actor, center in zip(models_by_name["21_员工账号与身份"]["actors"], ([46,155],[546,295])):
    actor["center"] = center

for name, model in models_by_name.items():
    source = models / (name + ".json")
    source.write_text(json.dumps(model, ensure_ascii=False, indent=2), encoding="utf8")
    subprocess.run([sys.executable,str(renderer),str(source),"--out",str(output),"--scale","3","--strict"],check=True)
