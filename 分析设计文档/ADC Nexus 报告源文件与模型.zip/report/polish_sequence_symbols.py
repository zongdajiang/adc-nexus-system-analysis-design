"""Apply the report's business and analysis lifeline conventions."""
import json
from pathlib import Path
import re
from tempfile import TemporaryDirectory

import pymupdf

from render_state_diagrams import MODEL_OUT, OUT, renderer, save_vector_pdf


REPORT = Path(__file__).resolve().parent
MANIFEST = REPORT.parent / "校核记录" / "序列图符号核验.json"
SEQUENCE_LABELS = ("fig:as-is-", "fig:to-be-", "fig:seq-", "fig:data-access-sequence",
                   "fig:staff-demo-sequence", "fig:miniapp-target-sequence", "fig:patient-booking-target")


def close(first, second, limit=.05):
    return abs(first - second) <= limit


def baseline_at(ops, x, threshold, radius):
    for op in ops:
        if op["type"] != "line" or op["arrow"] or op["dash"] or len(op["points"]) != 2:
            continue
        (a, y), (b, end_y) = op["points"]
        if (close(y, end_y) and close(y, threshold, 5) and close((a+b)/2, x, 1)
                and abs(a-b) >= radius*1.6):
            return op
    return None


def symbol_baselines(scene):
    """Use lifeline centers to distinguish header symbols from other circles."""
    ops = scene.ops
    circles = [op for op in ops if op["type"] == "ellipse" and op["stroke"] != "none"
               and close(op["rx"], op["ry"])]
    stems = [(x, y) for op in ops if op["type"] == "line" and op["dash"] and len(op["points"]) == 2
             for ((x, y), (end_x, end_y)) in [op["points"]]
             if close(x, end_x) and end_y-y >= 90]
    heads = [circle for circle in circles if circle["rx"] >= 14
             and any(close(circle["cx"], x) and 0 <= y-circle["cy"]-circle["ry"] <= 56 for x, y in stems)]
    bars = []
    workers = 0
    for circle in heads:
        x, cy, radius = circle["cx"], circle["cy"], circle["rx"]
        if any(close(head["cx"], x) and head["rx"] < radius/2 and abs(head["cy"]-cy) < radius
               for head in circles):
            workers += 1
            continue
        bottom = cy+radius
        bar = baseline_at(ops, x, bottom, radius)
        if bar is None:
            # Keep a narrow optical gap under the symbol. A boundary or control
            # retains its original side marker or arrow at the top.
            gap = 2 if radius >= 32 else 3
            line_y = bottom + gap
            half = radius * .94
            stroke_width = min(float(circle["sw"]), 1.8)
            x_min, x_max = x-half, x+half
            for label in scene.audit()["text_bounds"]:
                left, top, right, end = label["box"]
                assert min(x_max, right) <= max(x_min, left) or not top <= line_y <= end, label
            scene.line([(x_min, line_y), (x_max, line_y)], color=circle["stroke"], sw=stroke_width)
            bar = scene.ops[-1]
            bar["role"] = "lifeline-baseline"
        bars.append((circle, bar))
    return bars, workers


def update_native_plate(path, bars):
    """Map each baseline to its matching circle in the original vector plate."""
    pending = path.with_suffix(".pending.pdf")
    with pymupdf.open(path) as doc:
        page = doc[0]
        original = page.get_drawings()
        drawn_circles = [drawing for drawing in original if drawing["color"] is not None
                         and all(item[0] == "c" for item in drawing["items"])
                         and len(drawing["items"]) == 4 and drawing["rect"].width >= 19
                         and close(drawing["rect"].width, drawing["rect"].height)]
        native = [drawing for drawing in drawn_circles
                  if not any(other["rect"].width < drawing["rect"].width/2
                             and other["rect"] in drawing["rect"]
                             for other in original if len(other["items"]) == 4 and
                             all(item[0] == "c" for item in other["items"]))]
        native.sort(key=lambda item: (round(item["rect"].y0, 1), item["rect"].x0))
        bars.sort(key=lambda pair: (round(pair[0]["cy"], 1), pair[0]["cx"]))
        assert len(native) == len(bars), path
        line_plan = []
        offset = None
        for (circle, bar), figure in zip(bars, native):
            bounds = figure["rect"]
            scale = bounds.width / (2*circle["rx"])
            cx, cy = (bounds.x0+bounds.x1)/2, (bounds.y0+bounds.y1)/2
            mapped_offset = cx-scale*circle["cx"], cy-scale*circle["cy"]
            if offset is None:
                offset = mapped_offset
            assert all(close(a, b, .12) for a, b in zip(offset, mapped_offset)), (path, circle)
            points = [pymupdf.Point(cx+scale*(x-circle["cx"]), cy+scale*(y-circle["cy"])) for x, y in bar["points"]]
            if not any(any(item[0] == "l" and all(close(a.x, b.x, .12) and close(a.y, b.y, .12)
                            for a, b in zip(item[1:], points)) for item in drawing["items"])
                       for drawing in original):
                line_plan.append((points, figure["color"], scale*bar["sw"]))
        if not line_plan:
            return
        for points, color, width in line_plan:
            page.draw_line(*points, color=color, width=width, overlay=True)
        doc.save(pending, garbage=3, deflate=True)
    pending.replace(path)


def entity_diagonal(circle):
    reach = circle["rx"] - .6
    x, y = circle["cx"], circle["cy"]
    return {"type": "line", "points": [[x, y+reach], [x+reach, y]],
            "arrow": None, "dash": False, "color": "#676764", "sw": 1.2,
            "role": "entity-diagonal"}


def analysis_heads(scene, name):
    """Keep participants and message positions, updating only the head artwork."""
    model = sorted(MODEL_OUT.rglob(name+".json"), reverse=True)[0]
    participants = json.loads(model.read_text(encoding="utf-8"))["participants"]
    stems = [op["points"][0][0] for op in scene.ops if op["type"] == "line" and op["dash"]
             and len(op["points"]) == 2 and op["points"][0][1] == 130
             and op["points"][0][0] == op["points"][1][0]]
    replace, remove, headers, anchors, diagonals = {}, [], [], [], []
    entities = 0
    for x, participant in zip(stems, participants, strict=True):
        kind = participant["kind"]
        if kind == "actor":
            continue
        if kind in ("boundary", "control"):
            circle, = (op for op in scene.ops if op["type"] == "ellipse"
                       and close(op["cx"], x) and op["cy"] == 64 and op["stroke"] != "none")
            anchors.append(circle)
            bar = baseline_at(scene.ops, x, 86, circle["rx"])
            if bar:
                remove.append(bar)
            continue
        assert kind == "entity", participant
        entities += 1
        rectangle = next((op for op in scene.ops if op["type"] == "rect"
                          and close(op["x"]+op["w"]/2, x) and op["y"] == 43 and op["h"] == 50), None)
        if rectangle is None:
            assert baseline_at(scene.ops, x, 86, 22), participant
            circle, = (op for op in scene.ops if op["type"] == "ellipse"
                       and close(op["cx"], x) and op["cy"] == 64 and op["stroke"] != "none")
            diagonal = entity_diagonal(circle)
            if diagonal not in scene.ops:
                diagonals.append(diagonal)
            continue
        index = scene.ops.index(rectangle)
        text = scene.ops[index+1]
        assert text["type"] == "text" and close(text["x"], x), participant
        assert " ".join(text["text"].split()) == " ".join(participant["label"].split()), participant
        glyph = renderer.Scene(scene.w, scene.h, scene.style)
        glyph.ellipse(x, 64, 22, 22, fill=rectangle["fill"], stroke=rectangle["stroke"],
                      sw=rectangle["sw"])
        glyph.ops.append(entity_diagonal(glyph.ops[-1]))
        glyph.line([(x-22, 89), (x+22, 89)], color=rectangle["stroke"], sw=rectangle["sw"])
        glyph.ops[-1]["role"] = "entity-baseline"
        glyph.ops.append({**text, "y": 94, "container": None})
        replace[index] = glyph.ops
        replace[index+1] = []
        headers.append((rectangle, glyph.ops))
    scene.ops = [replacement for i, op in enumerate(scene.ops) if op not in remove
                 for replacement in replace.get(i, [op])]
    scene.ops.extend(diagonals)
    assert sum(op.get("role") == "entity-diagonal" for op in scene.ops) == entities, name
    assert not scene.audit()["issues"], (name, scene.audit()["issues"])
    return entities, anchors, headers, remove, diagonals


def update_analysis_plate(path, scene, anchors, headers, remove, diagonals):
    """Edit vector heads on native-size pages, preserving the original message artwork."""
    pending = path.with_suffix(".pending.pdf")
    with pymupdf.open(path) as doc, TemporaryDirectory() as folder:
        page = doc[0]
        shapes = page.get_drawings()
        circles = [item["rect"] for item in shapes if item["color"] is not None
                   and item["rect"].width > 30 and close(item["rect"].width, item["rect"].height)
                   and len(item["items"]) == 4 and all(part[0] == "c" for part in item["items"])]
        circles = sorted(circles, key=lambda rect: rect.x0)[:len(anchors)]
        assert len(circles) == len(anchors)
        box, ref = circles[0], anchors[0]
        scale = box.width / (2*ref["rx"])
        x0 = box.x0 - scale*(ref["cx"]-ref["rx"])
        y0 = box.y0 - scale*(ref["cy"]-ref["ry"])
        for box, ref in zip(circles, anchors, strict=True):
            assert close(box.x0, x0+scale*(ref["cx"]-ref["rx"]), .15)
            assert close(box.y0, y0+scale*(ref["cy"]-ref["ry"]), .15)

        def area(left, top, right, bottom):
            return pymupdf.Rect(x0+scale*left, y0+scale*top, x0+scale*right, y0+scale*bottom)

        for old, _ in headers:
            # Vector redaction includes the stroke's possible miter extent.
            pad = 5 * old["sw"] + 1
            page.add_redact_annot(area(old["x"]-pad, old["y"]-pad,
                                       old["x"]+old["w"]+pad, old["y"]+old["h"]+pad), fill=False)
        for bar in remove:
            (left, y), (right, _) = bar["points"]
            page.add_redact_annot(area(left-1.5, y-1.2, right+1.5, y+1.2), fill=False)
        if headers or remove:
            page.apply_redactions(images=0, graphics=pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED)
        if headers:
            overlay = renderer.Scene(scene.w, scene.h, scene.style)
            overlay.ops = [op for _, head in headers for op in head]
            temporary = Path(folder)/"heads.pdf"
            save_vector_pdf(overlay, temporary, "Sequence lifeline heads")
            with pymupdf.open(stream=temporary.read_bytes(), filetype="pdf") as glyphs:
                page.show_pdf_page(area(0, 0, scene.w, scene.h), glyphs, 0, overlay=True)
        for diagonal in diagonals:
            points = [pymupdf.Point(x0+scale*x, y0+scale*y) for x, y in diagonal["points"]]
            color = tuple(int(diagonal["color"][i:i+2], 16)/255 for i in (1, 3, 5))
            page.draw_line(*points, color=color, width=scale*diagonal["sw"], overlay=True)
        doc.save(pending, garbage=3, deflate=True)
    pending.replace(path)


def main():
    tex = "\n".join(path.read_text(encoding="utf-8") for path in sorted(REPORT.glob("*.tex")))
    macros = re.findall(r"\\(fig\w+)\{([^}]+)\}\{([^}]+)\}\{([^}]+)\}", tex)
    sequence = {name: (macro, caption) for macro, name, caption, label in macros if label.startswith(SEQUENCE_LABELS)}
    jobs = dict(sequence)
    for name, (macro, caption) in sequence.items():
        if macro == "figoverview":
            for path in OUT.glob(name + "_*.scene.json"):
                jobs[path.name.removesuffix(".scene.json")] = ("detail", caption)
    proof = {}
    for name, (macro, caption) in jobs.items():
        path = OUT / (name+".scene.json")
        data = json.loads(path.read_text(encoding="utf-8"))
        scene = renderer.Scene(data["width"], data["height"], renderer.PROFILES["mayuyang"])
        scene.ops = data["ops"]
        business = name not in sequence or any(label.startswith(("fig:as-is-", "fig:to-be-"))
                                               for _, stem, _, label in macros if stem == name)
        if business:
            original_count = len(scene.ops)
            bars, workers = symbol_baselines(scene)
            proof[name] = {"in_report": name in sequence, "circular_non_human": len(bars),
                           "human_in_circle": workers}
            if len(scene.ops) == original_count:
                continue
        else:
            entities, anchors, edits, removed, diagonals = analysis_heads(scene, name)
            proof[name] = {"in_report": True, "entity_style_heads": entities,
                           "entity_diagonal_marks": entities,
                           "boundary_control_without_baseline": len(anchors)}
            if not edits and not removed and not diagonals:
                continue
            if macro == "figanalysisplate":
                plate = OUT / (name+"_body.pdf")
                if plate.exists():
                    save_vector_pdf(scene, plate, caption)
                else:
                    plate = OUT / "analysis_original_pages" / (name+".pdf")
                    update_analysis_plate(plate, scene, anchors, edits, removed, diagonals)
            (OUT / (name+".audit.json")).write_text(
                json.dumps(scene.audit(), ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        renderer.save_svg(scene, OUT / (name+".svg"))
        renderer.save_png(scene, OUT / (name+".png"), scale=3)
        renderer.save_drawio(scene, OUT / (name+".drawio"))
        data["ops"] = scene.ops
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        if macro == "figoverview":
            update_native_plate(OUT / "overview_original_pages" / (name+".pdf"), bars)
        elif macro == "figclassvector":
            save_vector_pdf(scene, OUT / (name+"_vector.pdf"), caption)
    MANIFEST.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    heads = sum(record.get("entity_style_heads", 0) for record in proof.values())
    print(f"{len(sequence)} report sequence diagrams, {heads} entity-style heads")


if __name__ == "__main__":
    main()
