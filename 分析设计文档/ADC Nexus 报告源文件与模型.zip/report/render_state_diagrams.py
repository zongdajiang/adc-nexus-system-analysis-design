"""Render the audited state plates from shared geometry."""
from pathlib import Path
import importlib.util
import json
import math
import shutil
import sys
from reportlab.lib.colors import toColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "assets/uml"
MODEL_OUT = ROOT / "models/uml"
spec = importlib.util.spec_from_file_location(
    "adc_scene", Path(sys.argv[1]))
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)

INK, LINE, TEAL = "#20313B", "#53656F", "#2D6E73"
PALE, AMBER, GREEN, MUTED = "#F3F8F8", "#FFF7E8", "#EDF7F1", "#64747C"
STYLE = dict(renderer.PROFILES["mayuyang"], font="Microsoft YaHei", size=18,
             stroke=LINE, line=1.8)
pdfmetrics.registerFont(TTFont("YaHei", r"C:\Windows\Fonts\msyh.ttc", subfontIndex=0))
pdfmetrics.registerFont(TTFont("Song", r"C:\Windows\Fonts\simsun.ttc", subfontIndex=0))


def save_vector_pdf(scene, output, title):
    pdf = Canvas(str(output), pagesize=(scene.w, scene.h), pageCompression=1)
    pdf.setTitle(title)

    def shape_path(points):
        path = pdf.beginPath()
        path.moveTo(points[0][0], scene.h - points[0][1])
        for x, y in points[1:]:
            path.lineTo(x, scene.h - y)
        return path

    for op in scene.ops:
        kind = op["type"]
        if kind == "text":
            font = renderer.get_font(op["size"], op["family"], op["bold"])
            pdf.setFont("Song" if op["family"] == "SimSun" else "YaHei", op["size"])
            pdf.setFillColor(toColor(op["color"]))
            draw = {"start":pdf.drawString,"middle":pdf.drawCentredString,"end":pdf.drawRightString}[op["anchor"]]
            for n, line in enumerate(op["text"].split("\n")):
                baseline = op["y"] - font.getbbox(line or " ", anchor="ls")[1] + n * op["size"] * 1.25
                draw(op["x"], scene.h - baseline, line)
            continue
        if kind == "line":
            pdf.setStrokeColor(toColor(op["color"]))
            pdf.setLineWidth(op["sw"])
            pdf.setDash(5, 4) if op["dash"] else pdf.setDash()
            pdf.drawPath(shape_path(op["points"]))
            pdf.setDash()
            head = renderer.arrow_polygon(op["points"], op["arrow"], op["sw"])
            if head:
                pdf.setFillColor(toColor(op["color"]))
                pdf.drawPath(shape_path(head), stroke=1, fill=int(op["arrow"] != "open"))
            continue
        fill, stroke = op.get("fill","none"), op.get("stroke","none")
        fill = {"peach":"#fcead9","blue":"#eaf5ff"}.get(fill,fill)
        if fill != "none":
            pdf.setFillColor(toColor(fill))
        if stroke != "none":
            pdf.setStrokeColor(toColor(stroke))
            pdf.setLineWidth(op["sw"])
        colors = dict(stroke=int(stroke != "none"), fill=int(fill != "none"))
        if kind == "rect":
            pdf.roundRect(op["x"], scene.h-op["y"]-op["h"], op["w"], op["h"], op["rx"], **colors)
        elif kind == "ellipse":
            x, y, rx, ry = op["cx"], scene.h-op["cy"], op["rx"], op["ry"]
            pdf.ellipse(x-rx, y-ry, x+rx, y+ry, **colors)
        else:
            path = shape_path(op["points"])
            path.close()
            pdf.drawPath(path, **colors)
    pdf.save()


class Plate:
    def __init__(self, name, title, height=530):
        self.name = name
        self.title = title
        self.scene = renderer.Scene(1040, height, STYLE)
        self.nodes = []
        self.transitions = []

    def state(self, id, x, y, title, note, fill=PALE, w=210, h=88):
        s = self.scene
        box = [x-w/2, y-h/2, x+w/2, y+h/2]
        s.rect(box[0], box[1], w, h, fill=fill, stroke=LINE, sw=1.8, rx=12)
        s.rect(box[0], box[1]+3, 5, h-6, fill=TEAL, stroke="none", rx=2)
        s.box(id, box[0], box[1], w, h)
        s.text(x, y-29, title, size=28, color=INK, container=box, role="state-title")
        s.text(x, y+16, note, size=17, color=MUTED, container=box, role="state-note")
        self.nodes.append(dict(id=id, kind="state", title=title, note=note, box=box))

    def initial(self, x, y):
        self.scene.ellipse(x, y, 10, 10, fill=INK, stroke="none")
        self.nodes.append(dict(id="initial", kind="initial", center=[x, y]))

    def choice(self, x, y, r=25):
        self.scene.polygon([(x, y-r), (x+r, y), (x, y+r), (x-r, y)],
                           fill="white", stroke=LINE, sw=1.8)
        self.scene.box("risk_choice", x-r, y-r, 2*r, 2*r, kind="choice")
        self.scene.text(x, y-83, "风险分流", size=18, color=TEAL, role="choice-note")
        self.nodes.append(dict(id="risk_choice", kind="choice", center=[x, y], radius=r))

    def edge(self, id, src, dst, trigger, points, label, lx, ly,
             guard="", anchor="middle"):
        self.scene.line(points, arrow="filled", color=LINE, sw=1.8)
        # No white panel is ever painted over the nodes or connectors.
        if label:
            self.scene.text(lx, ly, label, size=18, color=INK,
                            anchor=anchor, role="transition-label")
        self.transitions.append(dict(id=id, source=src, target=dst, trigger=trigger,
                                     guard=guard, points=points, display=label))

    def note(self, x, y, value, anchor="middle"):
        self.scene.text(x, y, value, size=17, color=MUTED,
                        anchor=anchor, role="diagram-note")

    def save(self):
        s = self.scene
        audit = s.audit()
        issues = audit["issues"]
        clearances = []
        labels = [a for a in audit["text_bounds"]
                  if s.ops[a["op"]].get("role") in
                  ("transition-label", "choice-note", "diagram-note")]
        for label in labels:
            b = label["box"]
            for node in s.boxes:
                distance = rect_distance(b, node["box"])
                clearances.append(distance)
                if distance < 7:
                    issues.append(dict(type="label-node-clearance", text=label["text"],
                                       node=node["id"], distance=distance))
            for op in s.ops:
                if op["type"] != "line":
                    continue
                for p, q in zip(op["points"], op["points"][1:]):
                    if p[0] != q[0] and p[1] != q[1]:
                        issues.append(dict(type="nonorthogonal-connector", points=[p, q]))
                    # Text boxes use actual font metrics; expand by 5 px for
                    # line clearance. Arrowhead envelopes are checked as well.
                    pad = 5
                    expanded = [b[0]-pad, b[1]-pad, b[2]+pad, b[3]+pad]
                    if segment_hits_rect(p, q, expanded):
                        issues.append(dict(type="connector-label-clearance", text=label["text"],
                                           segment=[p, q]))
                head = renderer.arrow_polygon(op["points"], op["arrow"], op["sw"])
                if head:
                    hb = [min(p[0] for p in head), min(p[1] for p in head),
                          max(p[0] for p in head), max(p[1] for p in head)]
                    if rect_distance(b, hb) < 5:
                        issues.append(dict(type="arrow-label-clearance", text=label["text"]))
        # Connectors may touch only their own end nodes, never cross foreign states.
        for edge in self.transitions:
            for node in s.boxes:
                if node["id"] in (edge["source"], edge["target"]):
                    continue
                inner = [node["box"][0]+2, node["box"][1]+2,
                         node["box"][2]-2, node["box"][3]-2]
                if any(segment_hits_rect(p, q, inner)
                       for p, q in zip(edge["points"], edge["points"][1:])):
                    issues.append(dict(type="edge-crosses-foreign-node", edge=edge["id"],
                                       node=node["id"]))
        audit.update(label_node_min_clearance=round(min(clearances), 2),
                     white_mask_panels=0, orthogonal_connectors=True,
                     semantic_transition_count=len(self.transitions),
                     scope="文字、节点、连线及箭头净空；业务语义另与正文守卫表逐条核对。")
        model = dict(type="state", renderer="report/render_state_diagrams.py",
                     title=self.title, width=s.w, height=s.h,
                     caption_location="report-below", nodes=self.nodes,
                     transitions=self.transitions,
                     notation="UML state, initial pseudostate, choice; filled transition arrows")
        svg = OUT / f"{self.name}.svg"
        renderer.save_svg(s, svg)
        renderer.save_png(s, OUT / f"{self.name}.png", scale=3)
        renderer.save_drawio(s, OUT / f"{self.name}.drawio")
        for path, data in [(OUT/f"{self.name}.scene.json", dict(width=s.w, height=s.h, ops=s.ops)),
                           (OUT/f"{self.name}.audit.json", audit),
                           (MODEL_OUT/f"{self.name}.json", model),
                           (MODEL_OUT/f"{self.name}.state.json", model)]:
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        save_vector_pdf(s, OUT/f"{self.name}.pdf", self.title)
        shutil.copyfile(OUT/f"{self.name}.pdf", OUT/"state_sources"/f"{self.name}.pdf")
        uml = ["@startuml", "!include _state_style.puml"]
        for node in self.nodes:
            if node["kind"] == "state":
                uml.append(f'state "{node["title"]}" as {node["id"]}')
            elif node["kind"] == "choice":
                uml.append(f'state {node["id"]} <<choice>>')
        for e in self.transitions:
            src = "[*]" if e["source"] == "initial" else e["source"]
            label = e["trigger"]
            if e["guard"]:
                label += f' [{e["guard"]}]'
            uml.append(f'{src} --> {e["target"]}' + (f": {label.strip()}" if label else ""))
        uml.append("@enduml")
        for folder in (OUT, OUT/"state_sources"):
            (folder/f"{self.name}.puml").write_text("\n".join(uml)+"\n", encoding="utf-8")
        for suffix in (".svg", ".png", ".drawio"):
            # Buffered copying also works when a Windows font/image provider
            # retains a read handle and CopyFile2 requests incompatible access.
            with (OUT/f"{self.name}{suffix}").open("rb") as source, \
                 (OUT/"state_sources"/f"{self.name}{suffix}").open("wb") as target:
                shutil.copyfileobj(source, target)
        print(f"{self.name}: {len(self.transitions)} transitions; {len(issues)} layout issues")
        assert not issues, json.dumps(issues, ensure_ascii=False)


def rect_distance(a, b):
    return math.hypot(max(a[0]-b[2], b[0]-a[2], 0),
                      max(a[1]-b[3], b[1]-a[3], 0))


def segment_hits_rect(p, q, r):
    if p[0] == q[0]:
        return r[0] < p[0] < r[2] and max(min(p[1], q[1]), r[1]) < min(max(p[1], q[1]), r[3])
    if p[1] == q[1]:
        return r[1] < p[1] < r[3] and max(min(p[0], q[0]), r[0]) < min(max(p[0], q[0]), r[2])
    return False


def appointment():
    p = Plate("14_状态机_预约", "预约状态机")
    p.initial(35, 150)
    for id, x, title, note, fill in [
        ("confirmed", 230, "已预约", "资源已复核", PALE),
        ("arrived", 560, "已签到", "身份已核对", PALE),
        ("in_care", 890, "诊疗中", "正在提供服务", PALE),
        ("no_show", 230, "未到诊", "超过保留时限", AMBER),
        ("cancelled", 560, "已取消", "保留发起方与原因", AMBER),
        ("completed", 890, "已完成", "临床完成条件满足", GREEN)]:
        p.state(id, x, 150 if id in ("confirmed", "arrived", "in_care") else 430,
                title, note, fill)
    p.edge("T1", "initial", "confirmed", "", [(45,150),(125,150)],
           "", 80, 116)
    p.edge("T2", "confirmed", "arrived", "登记到诊", [(335,150),(455,150)],
           "T2 登记到诊",395,116,"预约状态为已预约且属当日，已核实身份")
    p.edge("T3", "arrived", "in_care", "开始诊疗", [(665,150),(785,150)],
           "T3 开始诊疗",725,116,"到诊交接和待处理风险已核对")
    p.edge("T4", "in_care", "completed", "完成就诊", [(890,194),(890,386)],
           "T4 完成就诊",910,275,"实施项目、病历签署及必要同意材料已核对",anchor="start")
    p.edge("T5", "confirmed", "cancelled", "取消预约", [(282,194),(282,290),(505,290),(505,386)],
           "T5 取消预约",395,254,"尚未到诊，保留取消原因与操作人")
    p.edge("T6", "arrived", "confirmed", "撤销签到", [(560,106),(560,63),(290,63),(290,106)],
           "T6 撤销签到",425,29,"无诊疗事实，填写更正原因并撤销关联就诊")
    p.edge("T7", "confirmed", "no_show", "标记未到诊", [(178,194),(178,386)],
           "T7 标记未到诊",157,274,"已超过预约结束时间及十五分钟保留时限",anchor="end")
    return p


def clinical():
    p = Plate("15_状态机_临床就诊", "临床就诊状态机", 495)
    p.initial(30, 154)
    p.state("review", 232, 154, "诊前核查", "已到诊，待核实风险", AMBER)
    p.state("waiting", 557, 154, "待接诊", "复核通过，等待开始")
    p.state("in_care", 882, 154, "诊疗中", "记录实际治疗")
    p.state("cancelled", 232, 399, "已撤销", "保留到诊更正记录", AMBER)
    p.state("completed", 882, 399, "已完成", "可交收费员开单", GREEN)
    p.edge("T1","initial","review","",[(40,154),(127,154)],
           "",74,119)
    p.edge("T2","review","waiting","完成复核",[(337,154),(452,154)],
           "T2 完成复核",395,123,"病史与风险处理结论已留痕")
    p.edge("T3","waiting","in_care","开始诊疗",[(662,154),(777,154)],
           "T3 开始诊疗",720,123,"复核通过，诊所和医师在用，实施日任职有效")
    p.edge("T4","in_care","completed","完成就诊",[(882,198),(882,355)],
           "T4 完成就诊",902,266,"完成核查通过，关联预约同步完成",anchor="start")
    p.edge("T5","review","cancelled","撤销到诊",[(232,198),(232,355)],
           "T5 撤销到诊",252,259,"尚未形成诊疗事实，填写更正原因",anchor="start")
    p.edge("T6","waiting","cancelled","撤销到诊",[(557,198),(557,399),(337,399)],
           "T6 撤销到诊",577,267,"尚未形成诊疗事实，填写更正原因",anchor="start")
    p.edge("T7","cancelled","review","再次签到",[(164,355),(164,198)],
           "T7\n再次签到",108,290,"当日预约重新签到并恢复原就诊")
    return p


def invoice():
    p = Plate("16_状态机_发票", "诊疗结算单收款状态机", 550)
    p.initial(35,195)
    p.state("issued",230,195,"已开具","尚无有效净收款")
    p.state("partial",560,195,"部分收款","0 < 净收款 < 应收")
    p.state("paid",890,195,"已结清","净收款 = 应收",GREEN)
    p.state("voided",230,455,"已作废","净收款 = 0 且已授权",AMBER)
    p.edge("T1","initial","issued","",[(45,195),(125,195)],
           "",68,161)
    p.edge("T2","issued","partial","部分收款",[(335,195),(455,195)],
           "T2 部分收款",395,161,"净收款大于零且小于应收金额")
    p.edge("T3","issued","paid","全额收款",[(230,151),(230,80),(890,80),(890,151)],
           "T3 一次全额收款",560,42,"一次收款后净收款等于应收金额")
    p.edge("T4","partial","paid","结清尾款",[(665,195),(785,195)],
           "T4 结清尾款",725,161,"追加收款后净收款等于应收金额")
    p.edge("T5","issued","voided","授权作废",[(230,239),(230,411)],
           "T5 授权作废",252,315,"期间允许写入，净收款为零，记录作废原因及操作者",anchor="start")
    p.edge("T6","partial","partial","继续部分收款",[(520,239),(520,310),(620,310),(620,239)],
           "T6 继续部分收款",570,326,"追加收款后净收款仍小于应收金额")
    p.note(515,432,"净收款按有效收款扣减退款计算。\n退款后的状态转换见下一图。",anchor="start")
    return p


def refund():
    p = Plate("16B_状态机_退款", "退款后结算状态判定", 550)
    p.state("paid",230,190,"已结清","退款前净收款 = 应收",GREEN,w=220)
    p.state("partial",810,190,"部分收款","0 < 净收款 < 应收",w=220)
    p.state("issued",520,450,"已开具","退款后净收款 = 0",AMBER,w=220)
    p.edge("T1","paid","partial","已结清后部分退款",[(340,190),(700,190)],
           "T1 部分退款",520,150,"0 < 净收款 < 应收")
    p.edge("T2","paid","issued","已结清后全额退款",[(230,234),(230,450),(410,450)],
           "T2 全额退款",252,318,"净收款为零，单据仍保留",anchor="start")
    p.edge("T3","partial","issued","部分收款后退至零",[(810,234),(810,450),(630,450)],
           "T3 退至零",788,318,"净收款为零",anchor="end")
    p.edge("T4","partial","partial","部分收款后继续退款",[(920,190),(990,190),(990,80),(810,80),(810,146)],
           "T4 退款后仍部分收款",850,42,"退款后净收款仍大于零且小于应收")
    p.note(520,515,"每笔退款均关联原收款；原始流水与凭据保留不变。")
    return p


def offer():
    p = Plate("39_状态机_候补邀请", "候补邀请状态机", 480)
    p.initial(30, 120)
    p.state("offered",230,120,"待答复","已记录候补邀请")
    p.state("accepted",820,120,"已接受","关联新正式预约",GREEN)
    p.state("declined",230,367,"已拒绝","保留答复时间与原因",AMBER)
    p.state("expired",820,367,"已过期","无新预约",AMBER)
    p.edge("W1","initial","offered","",[(40,120),(125,120)],"",76,89)
    p.edge("W2","offered","accepted","登记接受",[(335,120),(715,120)],
           "W2 登记接受",525,86,"有效期内明确确认，事务复核并创建唯一预约")
    p.edge("W3","offered","declined","登记拒绝",[(230,164),(230,323)],
           "W3 登记拒绝",250,235,"有效期内有拒绝原因",anchor="start")
    p.edge("W4","offered","expired","时效届满",[(335,145),(535,145),(535,367),(715,367)],
           "W4 时效届满",555,270,"达到 expires_at，禁止消费",anchor="start")
    p.note(520,455,"W4 说明可用性变化。读取投影显示过期，相关写操作处理存储状态。")
    return p


def followup():
    p = Plate("40_状态机_复诊建议", "复诊建议状态机", 550)
    p.initial(30, 142)
    p.state("pending",230,142,"待安排","保留建议及联系记录")
    p.state("scheduled",560,142,"已关联预约","待核实实际到诊")
    p.state("completed",890,142,"已完成","后续就诊完成",GREEN)
    p.state("declined",230,450,"患者拒绝","记录已结束",AMBER)
    p.state("cancelled",560,450,"已取消","保留原关联依据",AMBER)
    p.edge("R1","initial","pending","",[(40,142),(125,142)],"",78,112)
    p.edge("R2","pending","scheduled","关联预约",[(335,142),(455,142)],
           "R2 关联预约",395,112,"同一患者同一诊所，非来源预约且有效")
    p.edge("R3","scheduled","completed","核实完成",[(665,142),(785,142)],
           "R3 核实完成",725,112,"预约和随诊记录均完成")
    p.edge("R4","scheduled","pending","重新安排",[(560,98),(560,59),(230,59),(230,98)],
           "R4 重新安排",395,28,"原关联已取消或未到诊")
    p.edge("R5","pending","declined","记录拒绝",[(185,186),(185,406)],
           "R5 记录拒绝",165,275,"员工登记患者明确拒绝",anchor="end")
    p.edge("R5b","scheduled","declined","记录拒绝",[(485,186),(485,246),(265,246),(265,406)],
           "R5 记录拒绝",370,218,"员工登记患者明确拒绝")
    p.edge("R6","pending","cancelled","取消建议",[(306,186),(306,325),(495,325),(495,406)],
           "R6 取消建议",405,295,"员工结束建议，保留原预约")
    p.edge("R6b","scheduled","cancelled","取消建议",[(604,186),(604,406)],
           "R6 取消建议",624,295,"员工结束建议，保留原预约",anchor="start")
    return p


if __name__ == "__main__":
    for builder in (appointment,clinical,invoice,refund,offer,followup):
        builder().save()
