"""Draw the report's UML packages and use cases with explicit actor roles."""
import json
from itertools import combinations
from math import sqrt

from render_state_diagrams import MODEL_OUT, OUT, renderer, save_vector_pdf

MODELS = MODEL_OUT / "20261123"
INK, BRAND, MUTED = "#202D29", "#17473F", "#4E625C"
STYLE = dict(renderer.PROFILES["mayuyang"], font="Microsoft YaHei", size=23,
             stroke="#405B53", line=1.9)
GROUPS = {
    "患者档案与预约": ["UC-01", "UC-02", "UC-03", "UC-04", "UC-05", "UC-20", "UC-28", "UC-30", "UC-32"],
    "临床诊疗与收费": ["UC-06", "UC-07", "UC-08", "UC-09", "UC-10", "UC-27", "UC-29"],
    "运营与核算": ["UC-11", "UC-12", "UC-13", "UC-18", "UC-19", "UC-21",
                "UC-22", "UC-23", "UC-25", "UC-26", "UC-31", "UC-33"],
    "员工身份与访问": ["UC-14", "UC-16", "UC-17", "UC-24"],
}
ACTORS = {
    "front": "前台接待", "manager": "诊所经理", "dentist": "负责医师",
    "cashier": "收费员", "ops": "总部运营", "finance": "总部财务",
    "staff": "员工", "admin": "权限管理员", "patient": "患者", "wechat": "微信身份服务",
    "owner": "连锁经营负责人", "clinic_lead": "诊所负责人", "delivery": "验证码投递服务",
}


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def export(name, scene, model, uml):
    audit = scene.audit()
    assert not audit["issues"], (name, audit["issues"])
    audit.update(model=name, associations=model.get("associations", []))
    write_json(MODELS / (name + ".json"), model)
    write_json(OUT / (name + ".audit.json"), audit)
    write_json(OUT / (name + ".scene.json"), {"width": scene.w, "height": scene.h, "ops": scene.ops})
    renderer.save_svg(scene, OUT / (name + ".svg"))
    renderer.save_png(scene, OUT / (name + ".png"), scale=3)
    renderer.save_drawio(scene, OUT / (name + ".drawio"))
    save_vector_pdf(scene, OUT / (name + "_vector.pdf"), model["system"])
    (OUT / (name + ".puml")).write_text("\n".join(
        ["@startuml", "skinparam shadowing false", *uml, "@enduml", ""]), encoding="utf-8")


def package_shape(scene, x, y, width, height, text, outer=False):
    """Put the UML package name in the tab when displaying nested contents."""
    tab = renderer.measure(text, 24, STYLE["font"])[0] + 44
    scene.polygon([(x, y), (x+tab, y), (x+tab, y+39), (x+width, y+39),
                   (x+width, y+height), (x, y+height)], fill="#FFFFFF" if outer else "#F2F7F4")
    scene.line([(x, y+39), (x+tab, y+39)])
    scene.text(x+21, y+8, text, size=24, color=BRAND, anchor="start")


def package_diagram():
    scene = renderer.Scene(970, 520, STYLE)
    title = "ADC Nexus 员工端用例"
    package_shape(scene, 24, 12, 922, 492, title, outer=True)
    catalogue = (MODEL_OUT.parent / "use_cases.txt").read_text(encoding="utf-8")
    titles = {parts[0]: parts[1] for line in catalogue.splitlines()
              if line.startswith("UC-") for parts in [line.split("|")]}
    uml = [f'package "{title}" {{']
    for index, (group, cases) in enumerate(GROUPS.items()):
        x = 55 + index % 2 * 441
        y = 73 + index // 2 * 215
        package_shape(scene, x, y, 419, 191, group)
        uml.append(f'  package "{group}" {{')
        for j, code in enumerate(sorted(cases)):
            cx, cy = x + 64 + j % 4 * 97, y + 68 + j // 4 * 45
            scene.ellipse(cx, cy, 43, 17, fill="#FFFFFF", stroke="#69847A")
            scene.text(cx, cy-12, code, size=19, color=INK)
            uml.append(f'    usecase "{code}\\n{titles[code]}" as {code.lower().replace("-", "")}')
        uml.append("  }")
    uml.append("}")
    scene.counts = {"packages": 5, "catalogue_use_cases": sum(map(len, GROUPS.values()))}
    model = {"type": "package", "system": title, "packages": [
        {"name": name, "member_use_cases": codes} for name, codes in GROUPS.items()]}
    export("08_员工网页用例全景", scene, model, uml)


def crossed(edge, other):
    def side(a, b, p):
        return (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])
    a, b = edge
    c, d = other
    return side(a, b, c)*side(a, b, d) < -1e-8 and side(c, d, a)*side(c, d, b) < -1e-8


def enters_box(edge, box):
    x, y, right, bottom = box
    points = [(x, y), (right, y), (right, bottom), (x, bottom), (x, y)]
    return any(crossed(edge, border) for border in zip(points, points[1:]))


def draw_use_cases(name, cases, positions, subject="ADC Nexus 员工端", business=False):
    """A bang-prefixed role is a supporting actor that the use case calls."""
    assert {role.lstrip("!") for _, _, roles in cases for role in roles} == set(positions)
    width, row_gap = 970, 92
    first_row = max(118, 65-min(row for _, row in positions.values())*row_gap)
    height = int(first_row + max(len(cases)-1, max(row for _, row in positions.values()))*row_gap + 70)
    scene = renderer.Scene(width, height, STYLE)
    scene.rect(235, 14, 500, height-29, stroke="#71867D", fill="#FAFCFB")
    scene.text(485, 37, subject, size=25, bold=True, color=BRAND)
    scene.line([(261, 82), (709, 82)], color="#D6E1DB", sw=1.2)
    model = {"type": "usecase", "system": subject, "actors": [], "usecases": [],
             "directed_associations": True, "association_arrow": "open",
             "scope": "business" if business else "system",
             "notation": "软件方法：开放箭头区分主执行者与辅执行者"}
    anchors, actor_boxes, actor_lines = {}, {}, []
    for role, (side, row) in positions.items():
        y = first_row + row * row_gap
        x, direction = (145, 1) if side == "left" else (825, -1)
        if role == "owner":
            x += 18
        if role in {"wechat", "delivery"}:
            x = 843
        label = ACTORS[role]
        actor = {"id": role, "label": label, "center": [x, y]}
        model["actors"].append(actor)
        actor_lines.append(f'actor "{label}" as {role}')
        if role in {"wechat", "delivery"}:
            actor["kind"] = "external-system"
            scene.rect(x-93, y-36, 186, 70, stroke="#405B53")
            scene.text(x, y-27, "«actor»", size=17, color=MUTED)
            scene.text(x, y-2, label, size=21, color=INK)
            anchors[role] = (x+direction*93, y)
            actor_boxes[role] = (x-93, y-36, x+93, y+34)
        else:
            scene.actor(x, y-30, "", scale=1.24)
            size = 19 if business and len(label) > 5 else 23
            x_offset = 22 if business else 25
            scene.text(x-direction*x_offset, y-19, label, size=size, color=INK,
                       anchor="end" if side == "left" else "start")
            anchors[role] = (x+direction*17.36, y-7.43)
            actor_boxes[role] = (x-18, y-31, x+18, y+23)

    paths, node_boxes, links, case_lines = [], {}, [], []
    for row, (code, title, roles) in enumerate(cases):
        case_id = code.lower().replace("-", "")
        y = first_row + row*row_gap
        cx, rx, ry = 485, 187, 33
        scene.ellipse(cx, y, rx, ry, fill="#FFFFFF")
        scene.text(cx, y-24, code, size=17, color=MUTED)
        scene.text(cx, y-4, title, size=24, color=INK)
        scene.box(case_id, cx-rx, y-ry, rx*2, ry*2)
        node_boxes[case_id] = (cx-rx, y-ry, cx+rx, y+ry)
        model["usecases"].append({"id": case_id, "label": f"{code}\n{title}",
                                  "center": [cx, y], "actors": [r.lstrip("!") for r in roles]})
        case_lines.append(f'  usecase "{code}\\n{title}" as {case_id}')
        ports = {}
        for side in (-1, 1):
            peers = sorted((role for role in roles if (anchors[role.lstrip("!")][0]-cx)*side > 0),
                           key=lambda role: anchors[role.lstrip("!")][1])
            for index, role in enumerate(peers):
                dy = 19 * (index-(len(peers)-1)/2)
                ports[role] = (cx + side*rx*sqrt(1-(dy/ry)**2), y+dy)
        for role_id in roles:
            role = role_id.lstrip("!")
            start = anchors[role]
            end = ports[role_id]
            source, target, direction = role, case_id, "initiating"
            if role_id.startswith("!"):
                start, end = end, start
                source, target, direction = target, source, "supporting"
            scene.line([start, end], arrow="open", color="#31584C", sw=2.15)
            paths.append(((start, end), role, case_id))
            links.append(dict(source=source, target=target, role=direction))
    audit = scene.audit()
    for (edge, role, node), (other, _, _) in combinations(paths, 2):
        assert not crossed(edge, other), (name, role, node, edge, other)
    for edge, role, node in paths:
        blocked = [key for key, box in {**node_boxes, **actor_boxes}.items()
                   if key not in {role, node} and enters_box(edge, box)]
        blocked += [label["text"] for label in audit["text_bounds"] if enters_box(edge, label["box"])]
        assert not blocked, (name, role, node, blocked)
    scene.counts = {"actors": len(positions), "use_cases": len(cases), "associations": len(links)}
    model["associations"] = links
    export(name, scene, model,
           [*actor_lines, f'rectangle "{subject}" {{', *case_lines, "}",
            *(f'{link["source"]} -->> {link["target"]}' for link in links)])


def main():
    package_diagram()
    draw_use_cases("01_业务用例图", [
        ("BUC-01", "获得牙科诊疗服务", ["patient"]),
        ("BUC-04", "获得复诊与连续照护", ["patient"]),
    ], {"patient": ("left", .5)}, "安德鲁牙科连锁（ADC）", business=True)
    draw_use_cases("01C_门诊预约与结算业务用例", [
        ("BUC-02", "取得诊疗预约安排", ["patient"]),
        ("BUC-03", "完成诊疗费用结算", ["patient"]),
    ], {"patient": ("left", .5)}, "门诊预约与结算服务单元", business=True)
    draw_use_cases("01B_总部经营支持业务用例", [
        ("BUC-05", "取得跨诊所医师配置依据", ["owner"]),
        ("BUC-06", "取得诊所经营绩效分析", ["owner", "clinic_lead"]),
        ("BUC-07", "取得季度经营核算结论", ["owner"]),
        ("BUC-08", "评估候选诊所扩张可行性", ["owner"]),
    ], {"owner": ("left", 1.5), "clinic_lead": ("right", 1)}, "安德鲁牙科连锁总部经营支持单元",
        business=True)
    front_manager = ["front", "manager"]
    draw_use_cases("09_系统用例_患者与预约", [
        ("UC-01", "建立并维护患者档案", front_manager),
        ("UC-02", "安排诊疗预约", front_manager),
        ("UC-03", "变更诊疗预约", front_manager),
        ("UC-04", "办理患者到诊", front_manager),
        ("UC-20b", "联系并核实患者复诊", front_manager),
        ("UC-05", "安排候补预约", [*front_manager, "dentist"]),
        ("UC-20a", "登记患者复诊建议", ["dentist"]),
    ], {"front": ("left", 2.1), "manager": ("right", 2.25), "dentist": ("left", 5.91)})
    draw_use_cases("10_系统用例_临床与结算", [
        ("UC-06", "记录临床就诊", ["dentist"]),
        ("UC-07", "制定治疗计划", ["dentist"]),
        ("UC-08", "完成临床就诊", ["dentist"]),
        ("UC-27", "查阅接诊与就诊记录", ["dentist", "manager"]),
        ("UC-09", "生成诊疗结算单", ["cashier", "manager"]),
        ("UC-10", "处理收款与退款", ["cashier", "manager"]),
        ("UC-29", "查阅结算单与收退明细", ["cashier", "manager", "finance"]),
    ], {"dentist": ("left", 1.5), "cashier": ("left", 5), "manager": ("right", 4.4), "finance": ("right", 6.4)})
    draw_use_cases("11_系统用例_网络经营与治理", [
        ("UC-11", "维护牙医资质与任职", ["ops"]),
        ("UC-22", "维护治疗项目目录", ["ops"]),
        ("UC-21a", "建立候选诊所测算方案", ["ops"]),
        ("UC-21b", "查阅候选诊所测算结果", ["ops", "finance"]),
        ("UC-13", "分析经营绩效与资质覆盖", ["ops", "finance", "manager"]),
        ("UC-19", "查看当日诊所运营", ["manager"]),
    ], {"ops": ("left", 1.8), "finance": ("right", 3.5), "manager": ("left", 5)})
    draw_use_cases("11B_系统用例_财务与账户", [
        ("UC-12", "关闭季度财务期间", ["finance"]),
        ("UC-25", "核实与归集期间成本费用", ["finance"]),
        ("UC-26", "查阅期间核算结果", ["finance", "manager"]),
    ], {"finance": ("left", 1), "manager": ("right", 2)})
    draw_use_cases("11C_系统用例_排班与牙椅", [
        ("UC-18", "维护排班与牙椅资源", ["manager", "ops"]),
        ("UC-23", "维护诊所基础资料", ["manager", "ops"]),
    ], {"manager": ("left", .5), "ops": ("right", .5)})
    draw_use_cases("21_员工账号与身份", [
        ("UC-16", "验证员工登录身份", ["staff", "!delivery"]),
        ("UC-17a", "激活员工账号", ["staff", "!delivery"]),
        ("UC-17b", "管理本人密码", ["staff", "!delivery"]),
        ("UC-14", "管理账户与访问范围", ["admin"]),
        ("UC-24", "核查系统操作记录", ["admin"]),
    ], {"staff": ("left", 1), "delivery": ("right", 1), "admin": ("right", 3.5)})
    review_roles = {"front": ("left", -.78), "manager": ("left", 0), "dentist": ("left", .78),
                    "cashier": ("right", -.45), "ops": ("right", .45)}
    draw_use_cases("11D_岗位查阅患者档案", [
        ("UC-28", "按权限调阅患者档案", list(review_roles)),
    ], review_roles)
    draw_use_cases("11E_岗位查阅预约日程", [
        ("UC-30", "按权限查阅预约日程", list(review_roles)),
    ], review_roles)
    for name, code, goal, roles in [
        ("11F_岗位查阅诊所配置", "UC-31", "查阅诊所与资源配置",
         ["manager", "front", "ops", "finance", "admin"]),
        ("11G_岗位查阅候补与复诊", "UC-32", "查阅候补与复诊进度",
         ["manager", "front", "dentist", "ops"]),
        ("11H_岗位经营概览", "UC-33", "查阅岗位经营概览",
         ["front", "cashier", "ops", "finance", "admin"]),
    ]:
        slots = [("left", -.78), ("left", 0), ("left", .78), ("right", -.45), ("right", .45)]
        if len(roles) == 4:
            slots = [("left", -.45), ("left", .45), ("right", -.45), ("right", .45)]
        draw_use_cases(name, [(code, goal, roles)], dict(zip(roles, slots, strict=True)))
    draw_use_cases("43_患者目标用例图", [
        ("UC-15a", "建立会话并申请档案绑定", ["patient", "!wechat"]),
        ("UC-15b", "查询本人预约、就诊与账单", ["patient"]),
        ("UC-15c", "选择时段并安排预约", ["patient"]),
        ("UC-15d", "改期或取消本人预约", ["patient"]),
    ], {"patient": ("left", 1.5), "wechat": ("right", 0)}, "ADC 患者小程序（目标设计）")


def redraw_appointment_domain():
    name = "12_领域类图_患者与预约"
    path = MODEL_OUT / (name + ".json")
    model = json.loads(path.read_text(encoding="utf-8"))
    scene = renderer.render_classes(model, renderer.PROFILES[model["profile"]])
    audit = scene.audit()
    assert not audit["issues"], audit["issues"]
    for label in audit["text_bounds"]:
        if scene.ops[label["op"]].get("container"):
            continue
        for node in scene.boxes:
            a, b = label["box"], node["box"]
            assert min(a[2], b[2]) <= max(a[0], b[0]) or min(a[3], b[3]) <= max(a[1], b[1]), label
    write_json(OUT / (name + ".audit.json"), audit)
    write_json(OUT / (name + ".scene.json"), {"width": scene.w, "height": scene.h, "ops": scene.ops})
    renderer.save_svg(scene, OUT / (name + ".svg"))
    renderer.save_png(scene, OUT / (name + ".png"), scale=3)
    renderer.save_drawio(scene, OUT / (name + ".drawio"))
    save_vector_pdf(scene, OUT / (name + "_vector.pdf"), "患者与预约领域类图")


if __name__ == "__main__":
    main()
    redraw_appointment_domain()
