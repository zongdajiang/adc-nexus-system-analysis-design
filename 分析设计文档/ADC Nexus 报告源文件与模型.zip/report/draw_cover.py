"""Draw the report cover's dental illustration as a printable vector."""
from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.pdfgen.canvas import Canvas


def draw_cover(destination):
    page = Canvas(str(destination), pagesize=(220, 365), pageCompression=1, invariant=True)
    page.setFillColor(HexColor("#EAF2ED"))
    page.rect(0, 0, 220, 365, fill=1, stroke=0)
    page.setStrokeColor(HexColor("#B8CFC2"))
    page.setLineWidth(.7)
    page.rect(16, 16, 188, 333, stroke=1, fill=0)

    page.saveState()
    overlay = page.beginPath()
    overlay.rect(17, 17, 186, 331)
    page.clipPath(overlay, stroke=0, fill=0)
    for radius in (41, 62, 84, 105, 126):
        page.circle(145, 195, radius, fill=0, stroke=1)
    page.line(145, 17, 145, 348)
    page.line(17, 195, 203, 195)
    page.restoreState()

    tooth = page.beginPath()
    tooth.moveTo(105, 259)
    tooth.curveTo(86, 270, 61, 264, 50, 241)
    tooth.curveTo(38, 216, 54, 191, 61, 175)
    tooth.curveTo(70, 153, 65, 110, 83, 96)
    tooth.curveTo(98, 84, 97, 139, 109, 153)
    tooth.curveTo(118, 163, 128, 147, 131, 132)
    tooth.curveTo(138, 105, 141, 88, 151, 101)
    tooth.curveTo(165, 118, 159, 157, 172, 181)
    tooth.curveTo(183, 202, 191, 231, 175, 249)
    tooth.curveTo(155, 273, 130, 250, 105, 259)
    tooth.close()
    page.setFillColor(HexColor("#F9FCFA"))
    page.setStrokeColor(HexColor("#346B5D"))
    page.setLineWidth(1.6)
    page.setLineJoin(1)
    page.drawPath(tooth, stroke=1, fill=1)
    crease = page.beginPath()
    crease.moveTo(86, 235)
    crease.curveTo(101, 241, 117, 227, 142, 237)
    page.setStrokeColor(HexColor("#719689"))
    page.setLineWidth(1)
    page.drawPath(crease)
    page.setStrokeColor(HexColor("#AA8C58"))
    page.setLineWidth(1.4)
    page.line(16, 304, 46, 304)
    page.line(16, 304, 16, 337)
    page.save()


if __name__ == "__main__":
    draw_cover(Path(__file__).resolve().parents[1] / "assets/uml/cover-dental.pdf")
