"""Keep the supplemental cases, catalogue and implementation trace aligned."""
from pathlib import Path

REPORT = Path(__file__).resolve().parent
MODEL = REPORT.parent / "models/use_cases.txt"
ROWS = [
    (22, "维护治疗项目目录", "总部运营", "治疗项目新增、收费标准调整或旧项目退役。",
     "持有目录维护权限及连锁范围授权，能够说明变更原因。",
     "保存项目版本、价格、预计成本、时长、生效区间和资质要求，保留审计证据。",
     ["选定项目编码，提供名称、分类、时长、标准价格、估算成本与资质清单。",
      "指定生效日期。更新现有编码时提交当前版本的校验摘要。",
      "系统校验区间、资质类型及受影响预约，保存新版本和对应的资质要求。",
      "系统返回项目标识；既有实施和结算的价格快照可继续查阅。"],
     ["2a 新版本日期须晚于今天和上一版本起始日；首次建立可从今天生效。",
      "3a 版本已变化、受影响预约或资质无效时拒绝。停用时同时检查未结束就诊的治疗计划。"],
     "诊所设置 → 治疗项目", ["/resources"], "catalog.manage",
     "PracticeSetup.catalog、catalog_retire；treatment_catalog、treatment_qualification_requirements；配置专项"),
    (23, "维护诊所基本资料", "诊所经理、总部运营", "新增诊所或更新现有诊所的地址、联系方式、容量或状态。",
     "具备诊所资料维护权限；修改限授权诊所，新建要求连锁范围授权。",
     "诊所资料有效保存，保留变更原因和修改前后证据。",
     ["从诊所档案选择记录，或在连锁授权范围内新增。",
      "填写名称、城市、地址、牙椅容量、联系方式及状态。",
      "系统核对范围、有效椅位数量及变更时的资料摘要。",
      "系统保存资料并写入变更记录。"],
     ["3a 容量低于有效牙椅数量、邮箱非法或已并发更正时拒绝。",
      "3b 停用时若仍有受影响的有效预约，提示先处理预约。"],
     "诊所设置 → 诊所档案", ["/resources"], "clinic.manage",
     "PracticeSetup.command；clinics、clinic_chairs、audit_events；配置专项"),
    (24, "核查系统操作记录", "权限管理员", "核实关键变更、授权调整或拒绝事件。",
     "会话有效且持有操作记录读取权限。",
     "取得授权范围内最近的操作记录，核对经办人、业务对象、时间、原因及结果。",
     ["权限管理员进入审计记录页。",
      "系统按授权范围查询记录，按记录标识降序返回最多 400 条。",
      "管理员依据动作、对象和结果核实变更。"],
     ["2a 账号无审计权限时拒绝请求。",
      "2b 查询范围内没有记录时显示空结果。"],
     "审计记录", ["/audit"], "audit.read",
     "Workforce.auditData；audit_events、app_users；岗位职责与操作留痕回归"),
    (25, "核实与归集期间成本费用", "总部财务", "账期内出现待核实的诊所费用或实际治疗成本。",
     "相关期间开放，记录属于授权诊所，具备成本费用维护权限。",
     "费用及治疗成本的凭据、核实结果、允许的分摊和必要审计可复核。",
     ["选定季度，核对待处理成本或费用及其凭据。",
      "财务凭证据登记已核实费用，或对既有费用提交核实、修改、取消。",
      "系统复核期间、诊所、记录摘要、金额及已分摊情况。",
      "财务对符合条件的已核实费用登记分摊，或确认实际治疗成本。"],
     ["2a 新登记的费用保存为已核实；已有待核实费用须单独确认。",
      "3a 关闭期间、已撤销记录或摘要变化拒绝普通变更。",
      "3b 已分摊费用不能直接取消；更正金额不得小于已分摊金额。"],
     "期间核算 → 治疗成本与运营费用", ["/finance/periods"], "expense.manage",
     "Finance.periodCommand；operating_expenses、treatment_cost_entries、dentist_expense_allocations；经营费用回归"),
    (26, "查阅期间核算结果", "诊所经理、总部财务", "按季度核对诊所经营结果或跟踪开放期间的账务情况。",
     "具备期间读取权，经营资料按诊所范围投影。",
     "获取季度汇总、费用与成本明细，并解释实时金额或已核定结果的来源。",
     ["打开期间核算并选择季度。",
      "系统返回范围内的期间明细和汇总。",
      "开放期间查看现有数据；已关闭期间优先查看已保存的核定结果。"],
     ["2a 不具期间读取权时拒绝。",
      "3a 缺少历史核定结果时提示缺失；诊所经理的读取权不授予关闭和重开权限。"],
     "期间核算", ["/finance/periods"], "period.read",
     "Finance.periods；financial_reporting_periods、financial_period_results；经营事务与岗位专项"),
    (27, "查阅接诊与就诊记录", "负责医师、诊所经理", "科室需要查看待接诊患者或复核既往就诊。",
     "具备临床读取权；绑定医师身份时须满足本人负责条件。",
     "取得授权范围内的接诊列表与所选就诊详情。",
     ["按就诊状态或业务线索在接诊页定位记录。",
      "系统按诊所范围取数，对带医师标识的账号加上本人负责限制。",
      "打开详情，核对到诊、诊疗进度及可查看的临床资料。"],
     ["2a 访问他店或他医师负责的记录时，由对应范围规则拒绝。",
      "3a 本用例为查阅路径；修改和签署由 UC-06 至 UC-08 处理。"],
     "临床接诊／我的接诊", ["/visits", "/visits/{id}"], "clinical.read",
     "Clinical.list、detail、get；clinical_visits；临床读写及越权回归"),
    (28, "按权限调阅患者档案", "前台接待、负责医师、收费员、诊所经理、总部运营",
     "办理预约、核实接诊、对账或按职责查找患者。",
     "持有患者读取权，符合页内诊所或患者对象范围。",
     "取得匹配患者及可披露字段；可核对已授权的病史、过敏或联系资料。",
     ["按患者编号、姓名等可用线索检索，必要时按授权诊所筛选。",
      "系统分页返回记录，按有效权限处理敏感字段。",
      "打开患者档案，系统核对对象范围，再按资料权限返回必要明细。"],
     ["2a 无匹配患者时返回空结果。",
      "3a 无临床或档案明细授权时只返回许可范围内的摘要；越权访问拒绝。"],
     "患者档案", ["/patients", "/patients/{id}"], "patient.read",
     "Service.patients、patientDetail、patientAccess；patients、patient_allergies；资料读取与脱敏核查"),
    (29, "查阅结算单与收退明细", "收费员、诊所经理、总部财务", "查看应收、净收、逐项费用或核对原收款与退款。",
     "持有收费读取权，单据属于可访问诊所。",
     "取得结算明细、收款记录、退款及调整记录，并区分读写责任。",
     ["打开收费页，从授权单据中定位目标记录。",
      "系统验证单据归属，读取行项目、收款、退款和调整。",
      "用户核对应收、收退明细、未收金额和单据状态。"],
     ["2a 超出诊所范围或不存在的单据不可读取。",
      "3a 查阅保留已作废或已退记录的历史事实；写入依据 UC-09 或 UC-10。"],
     "收费 → 结算详情", ["/finance/invoices", "/finance/invoices/{id}"], "finance.read",
     "Finance.list、detail；invoices、payments、payment_refunds；收费和岗位运行证据"),
    (30, "按权限查阅预约日程", "前台接待、负责医师、收费员、诊所经理、总部运营",
     "需要掌握某服务日的预约、资源安排或到诊进度。",
     "持有预约读取权；诊所筛选有效。",
     "按服务日及授权范围查看预约安排，按需追溯单条预约状态历史。",
     ["选择服务日期及日历视图，必要时筛选医师或诊所。",
      "系统在有效诊所范围内查询，按筛选条件返回预约资料。",
      "打开预约详情核对当前状态、安排及变更记录。"],
     ["2a 超授权诊所的查询请求被拒绝。",
      "3a 历史未闭环记录可供核对。签到、改期及取消分别按 UC-03、UC-04 执行。"],
     "预约日历与详情", ["/appointments", "/appointments/{id}"], "appointment.read",
     "Scheduling.list、get、reviewState；appointments、appointment_status_history；跨日及权限回归"),
    (31, "查阅诊所与资源配置", "诊所经理、前台接待、总部运营、总部财务、权限管理员",
     "需要核对授权诊所的营业时间、可用资源或治疗项目配置。",
     "岗位工作台提供诊所设置入口，持有诊所读取权。",
     "取得授权范围内的诊所、营业时间、排班与牙椅配置，以及许可查阅的目录与人员资料。",
     ["员工进入诊所设置，选择诊所或所需的资料类别。",
      "系统按诊所读取授权返回门店资料、营业时间、排班、停诊例外及牙椅配置。",
      "员工核对相应配置。医师与任职、资质页签另按人员读取权开放。"],
     ["2a 诊所筛选超出授权范围时拒绝。",
      "3a 查阅权限不授予资料修改。维护操作分别见 UC-11、UC-18、UC-22、UC-23。"],
     "诊所设置", ["/resources"], "clinic.read",
     "Workforce.data；clinics、clinic_operating_hours、clinic_chairs；菜单与诊所配置接口核验"),
    (32, "查阅候补与复诊进度", "诊所经理、前台接待、负责医师、总部运营",
     "需要掌握患者候补、邀请结果或复诊建议的处理进度。",
     "岗位工作台提供候补与复诊入口。候补读取与复诊读取按各自权限校验。",
     "取得授权范围内的候补名单、邀请状态、复诊记录及允许查阅的跟进历史。",
     ["在候补与复诊页选择候补名单或复诊跟进。",
      "系统按授权诊所读取候补与邀请。读取复诊列表或详情时，额外检查复诊读取权和负责医师范围。",
      "员工核对处理进度及关联预约。复诊详情的联系号码仅向有复诊管理权的人员展示。"],
     ["2a 查阅范围内没有记录时显示空状态。越权读取拒绝。",
      "3a 总部运营可以查阅。候补办理及复诊写入分别受 UC-05、UC-20 的条件约束。"],
     "候补与复诊", ["/waitlist", "/followups", "/followups/{id}"], "appointment.read、followup.read",
     "Scheduling.waitlist、Followups.data；waitlist_entries、patient_followups；菜单与候补复诊接口核验"),
    (33, "查阅岗位经营概览", "前台接待、收费员、总部运营、总部财务、权限管理员",
     "员工开始当班，或需要核对所辖范围的经营汇总及业务入口。",
     "已建立有效会话，岗位工作台提供概览入口，持有概览读取权。",
     "显示授权诊所和日期区间内的岗位摘要。员工可据已有权限进入相关业务页面。",
     ["员工打开经营概览，选择适用的诊所和日期区间。",
      "系统汇总有效范围内的预约状态、诊所及日期统计。",
      "系统依据独立授权显示预约队列、收款摘要及相关快捷入口，员工按职责查看。"],
     ["2a 日期区间倒置或诊所超出权限时拒绝。无记录时保留零值和正常查询。",
      "3a 诊所经理的当日门诊工作台见 UC-19。概览入口不授予业务记录写权限。"],
     "经营概览", ["/dashboard"], "dashboard.read",
     "Service.dashboard；appointments、clinical_visits；岗位概览与授权范围核验"),
]


def write(path, lines):
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def generate():
    catalogue, specs, trace, model_lines = [], [], [], []
    for number, title, actors, trigger, condition, success, basic, exceptions, page, paths, permission, proof in ROWS:
        uc = f"UC-{number:02}"
        actor_text = actors
        if number in (28, 30):
            actor_text = r"\makecell[l]{前台接待、负责医师、诊所经理、\\收费员、总部运营}"
        elif number in (31, 32, 33):
            labels = actors.split("、")
            actor_text = r"\makecell[l]{" + "、".join(labels[:3]) + r"、\\" + "、".join(labels[3:]) + "}"
        catalogue.append(f"{uc} & {title} & {actor_text}" + r"\\")
        endpoint = "、".join(r"\path{" + route + "}" for route in paths)
        permissions = "、".join(r"\path{" + value + "}" for value in permission.split("、"))
        trace.append(f"{uc} & {page} & {endpoint} & " + permissions + "；"
                     + proof.split("；")[-1] + r"\\")
        specs.extend([
            rf"\clearpage\subsection{{{uc}\quad {title}}}\label{{uc:{uc}}}",
            r"\begin{CaseMetadata}",
            rf"\CaseLabel{{执行者}} & {actors}\\",
            r"\CaseLabel{实现状态} & 员工端已实现\\",
            rf"\CaseLabel{{触发}} & {trigger}\\",
            rf"\CaseLabel{{前置条件}} & {condition}\\",
            rf"\CaseLabel{{成功后置}} & {success}\\\bottomrule",
            r"\end{CaseMetadata}",
            r"\CaseHeading{基本路径}",
            r"\begin{enumerate}[leftmargin=2.2em,itemsep=4pt,topsep=3pt]",
            *(r"\item " + step for step in basic),
            r"\end{enumerate}",
            r"\CaseHeading{扩展路径}",
            r"\begin{description}[style=multiline,leftmargin=2.4em,labelwidth=2.1em,itemsep=4pt,topsep=3pt]",
            *(rf"\item[{item.split(' ', 1)[0]}] {item.split(' ', 1)[1]}" for item in exceptions),
            r"\end{description}",
            r"\CaseHeading{实现与验证}",
            rf"\noindent {page}。接口 {endpoint}；服务端核对相应权限 {permissions}。\\",
            r"\noindent " + proof.split("；")[-1] + "。", "",
        ])
        model_lines.append("|".join([uc, title, actors, trigger, condition, success, "；".join(basic),
                                     "；".join(exceptions), permission, "、".join(paths) + "；" + proof]))
    write(REPORT / "extended_case_catalogue.tex", catalogue)
    write(REPORT / "extended_case_specifications.tex", specs)
    write(REPORT / "extended_case_trace.tex", trace)
    original = [line for line in MODEL.read_text(encoding="utf-8").splitlines()
                if not line.startswith(tuple(f"UC-{row[0]:02}|" for row in ROWS))]
    # The project catalogue owns the historical UC identifiers.
    write(MODEL, [*original, *model_lines])


if __name__ == "__main__":
    generate()
