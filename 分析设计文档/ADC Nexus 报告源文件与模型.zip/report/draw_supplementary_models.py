"""Generate supplementary domain and interaction diagrams from explicit models."""
import json

from render_state_diagrams import MODEL_OUT, OUT, renderer, save_vector_pdf


CASES = MODEL_OUT / "20261123"


def export(stem, model, scene):
    audit = scene.audit()
    assert not audit["issues"], (stem, audit["issues"])
    files = [(CASES / f"{stem}.json", model), (OUT / f"{stem}.audit.json", audit),
             (OUT / f"{stem}.scene.json", {"width": scene.w, "height": scene.h, "ops": scene.ops})]
    for path, data in files:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    renderer.save_svg(scene, OUT / f"{stem}.svg")
    renderer.save_png(scene, OUT / f"{stem}.png", 3)
    renderer.save_drawio(scene, OUT / f"{stem}.drawio")
    renderer.save_plantuml(model, OUT / f"{stem}.puml")
    save_vector_pdf(scene, OUT / f"{stem}_vector.pdf", model["title"])


def sequence(stem, title, names, actions, active, basis):
    kinds = ["actor", "boundary", "control", "entity", "entity"]
    columns = [120, 362, 609, 861, 1113]
    participants = [dict(id=f"p{index}", label=name, kind=kind, x=x)
                    for index, (name, kind, x) in enumerate(zip(names, kinds, columns))]
    messages = [dict(from_=f"p{a}", to=f"p{b}", kind=kind, label=label, y=150+i*52)
                for i, (a, b, kind, label) in enumerate(actions)]
    for message in messages:
        message["from"] = message.pop("from_")
    model = dict(type="sequence", profile="b-enterprise", frame=True, title=title, font_size=20,
                 width=1250, height=messages[-1]["y"]+75,
                 participants=participants, messages=messages,
                 activations=[dict(participant=f"p{index}", start_message=start, end_message=end)
                              for index, start, end in active], basis=basis)
    scene = renderer.render_sequence(model, renderer.PROFILES["b-enterprise"])
    export(stem, model, scene)


def klass(name, x, y, attributes=(), width=260):
    return dict(id=name, name=name, position=[x, y], width=width, row_height=33, header_height=45,
                fill="#EAF3EF", attributes=[dict(visibility="-", name=field, type=field_type)
                                           for field, field_type in attributes], methods=[])


def link(a, b, ends, *, label="", kind="association"):
    start, end = ends
    return dict(from_=a, to=b, from_multiplicity=start, to_multiplicity=end, label=label, kind=kind)


def classes(stem, title, nodes, connections, basis, height=680):
    for relation in connections:
        relation["from"] = relation.pop("from_")
    model = dict(type="class", title=title, profile="mayuyang", semantic_relationship_view=True,
                 font_size=23, relation_label_font_size=20, multiplicity_font_size=21,
                 width=1180, height=height, classes=nodes, relations=connections, basis=basis)
    scene = renderer.render_classes(model, renderer.PROFILES["mayuyang"])
    export(stem, model, scene)


def main():
    sequence("45_分析序列_完成复诊跟进", "核实复诊跟进结果",
             ["前台接待或诊所经理", "复诊跟进页面", "复诊跟进服务", "复诊建议", "预约及就诊事实"], [
                 (0, 1, "call", "提交复诊完成核实"),
                 (1, 2, "call", "提交建议标识与版本"),
                 (2, 3, "call", "读取建议及关联预约"),
                 (3, 2, "return", "已安排建议"),
                 (2, 4, "call", "核对复诊完成事实"),
                 (4, 2, "return", "预约和就诊均完成"),
                 (2, 3, "call", "保存完成及跟进事件"),
                 (3, 2, "return", "已保存"),
                 (2, 1, "return", "返回完成结果"),
                 (1, 0, "return", "展示最新跟进状态"),
             ], [(1, 0, 9), (2, 1, 8), (3, 2, 3), (4, 4, 5), (3, 6, 7)],
             "UC-20；Followups.command complete；未关联或未实际完成则拒绝。同一事务记录事件并更新建议。")
    sequence("46_分析序列_登记退款", "按原收款登记退款",
             ["收费员或诊所经理", "结算单详情", "退款协调服务", "原收款及已退款", "结算单"], [
                 (0, 1, "call", "提交退款确认"),
                 (1, 2, "call", "提交原收款与金额"),
                 (2, 4, "call", "核对单据与所属范围"),
                 (4, 2, "return", "有效单据"),
                 (2, 3, "call", "核对收款及剩余可退额"),
                 (3, 2, "return", "该笔收款的可退额"),
                 (2, 3, "call", "登记本次退款流水"),
                 (3, 2, "return", "已保存退款事实"),
                 (2, 4, "call", "按净收款重算状态"),
                 (4, 2, "return", "最新状态与余额"),
                 (2, 1, "return", "返回登记结果"),
                 (1, 0, "return", "展示退款与结算结果"),
             ], [(1, 0, 11), (2, 1, 10), (4, 2, 3), (3, 4, 5), (3, 6, 7), (4, 8, 9)],
             "UC-10；Finance.command refund；权限、现金期间、授权凭据及退款上限未通过时拒绝。")
    sequence("47_分析序列_建立扩张情景", "建立候选诊所扩张情景",
             ["总部运营", "扩张测算页面", "扩张测算服务", "估算规则", "扩张情景"], [
                 (0, 1, "call", "填写候选点与输入假设"),
                 (1, 2, "call", "提交情景计算请求"),
                 (2, 3, "call", "核验范围并计算"),
                 (3, 2, "return", "收入及成本估算"),
                 (2, 4, "call", "保存候选点与测算"),
                 (4, 2, "return", "已保存草案"),
                 (2, 1, "return", "返回情景标识"),
                 (1, 0, "return", "展示估算与假设"),
             ], [(1, 0, 7), (2, 1, 6), (3, 2, 3), (4, 4, 5)],
             "UC-21a；Workforce.expansionCommand；保存草案、候选点、假设及结果。")
    classes("48_领域类图_复诊跟进", "复诊建议、预约与联系事件", [
        klass("患者", 50, 48, [("患者编号", "String")]),
        klass("临床就诊", 460, 48, [("就诊编号", "String")]),
        klass("后续预约", 870, 48, [("预约编号", "String")]),
        klass("复诊建议", 405, 262, [("建议日期", "Date"), ("允许联系", "Boolean"),
                                 ("状态", "FollowUpStatus")], width=370),
        klass("跟进事件", 455, 510, [("发生时间", "DateTime"), ("处理结果", "String")]),
    ], [link("患者", "复诊建议", ("1", "0..*"), label="复诊对象"),
        link("临床就诊", "复诊建议", ("1", "0..*"), label="来源"),
        link("后续预约", "复诊建议", ("0..1", "0..*"), label="可关联"),
        link("复诊建议", "跟进事件", ("1", "1..*"), kind="composition")],
        "UC-20；患者、来源就诊及可选预约由数据外键约束；新建议与初始事件同一事务建立。")
    classes("49_领域类图_扩张情景", "扩张情景、候选点及测算结果", [
        klass("扩张情景", 430, 36, [("情景编码", "String"), ("状态", "ScenarioStatus")], width=320),
        klass("候选诊所", 43, 310, [("城市", "String"), ("规划牙椅数", "Integer"),
                                 ("初始投资", "Money")], width=290),
        klass("测算假设", 445, 310, [("参数键", "String"), ("参数内容", "String")], width=290),
        klass("测算结果", 847, 310, [("季度收入", "Money"), ("季度贡献", "Money"),
                                  ("回收月数", "Integer")], width=290),
    ], [link("扩张情景", "候选诊所", ("1", "1..*"), kind="composition"),
        link("扩张情景", "测算假设", ("1", "1..*"), kind="composition"),
        link("扩张情景", "测算结果", ("1", "0..1"), kind="composition")],
        "UC-21a；子项归属同一情景。页面本次创建产生一个候选点及其测算资料；回收期无正贡献时不可用。",
        height=505)


if __name__ == "__main__":
    main()
