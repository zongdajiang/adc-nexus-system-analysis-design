"""Number native vector plates according to the final TeX label positions."""
import re
from io import BytesIO
from pathlib import Path
import pymupdf
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf._page import PageObject
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

report = Path(__file__).resolve().parent
assets = report.parent / "assets"
pdfmetrics.registerFont(TTFont("PlateCaption", r"C:\Windows\Fonts\msyh.ttc", subfontIndex=0))
pdfmetrics.registerFont(TTFont("PlateNumber", r"C:\Windows\Fonts\segoeui.ttf"))
labels = {label:(int(n),int(page)) for label,n,page in re.findall(
    r"\\newlabel\{(fig:[^}]+)\}\{\{(\d+)\}\{(\d+)\}", (report/"main.aux").read_text(encoding="utf8"))}
combined = "\n".join((report/name).read_text(encoding="utf8") for name in ("main.tex","d_erd_overviews.tex"))
numbered = assets/"erd"/"numbered_pages"
numbered.mkdir(exist_ok=True)
erd = PdfWriter()
for macro, name, title, label in re.findall(r"\\(figerdplate|figoverview|figanalysisplate)\{([^}]+)\}\{([^}]+)\}\{(fig:[^}]+)\}", combined):
    fig, printed_page = labels[label]
    is_erd = macro == "figerdplate"
    has_new_body = name in {"20C_分析序列_季度期间关闭", "20B_分析序列_经营绩效查询"}
    if is_erd:
        origin, target = assets/"erd"/"pages"/(name+".pdf"), numbered/(name+".pdf")
    else:
        kind = "overview" if macro == "figoverview" else "analysis"
        origin = assets/"uml"/(kind+"_original_pages")/(name+".pdf")
        target = assets/"uml"/(kind+"_pages")/(name+".pdf")
        if has_new_body:
            origin = assets/"uml"/(name+"_body.pdf")
    retained_caption_band = not is_erd and not has_new_body
    if retained_caption_band:
        # Remove the old caption from both the visual page and the accessible text.
        with pymupdf.open(origin) as source:
            pdf_page = source[0]
            bounds = pdf_page.rect
            pdf_page.add_redact_annot((0, bounds.height-61, bounds.width, bounds.height), fill=False)
            pdf_page.apply_redactions(images=0, graphics=0, text=0)
            page = PdfReader(BytesIO(source.tobytes())).pages[0]
    else:
        page = PdfReader(origin).pages[0]
    width, height = float(page.mediabox.width), float(page.mediabox.height)
    band = min(170,max(88,width*.07)) if is_erd else (76 if has_new_body else 0)
    buffer = BytesIO()
    overlay = canvas.Canvas(buffer, pagesize=(width,height+band), pageCompression=1)
    size = min(38,max(18,width*.017)) if is_erd else 21
    margin = min(76, max(29, width*.036))
    caption_y = band*.48 if is_erd else 40
    overlay.setStrokeColor(HexColor("#C5D4CE"))
    overlay.setLineWidth(min(1.5, max(.65, width*.00075)))
    overlay.line(margin, caption_y-11, width-margin, caption_y-11)
    overlay.setFillColor(HexColor("#17473F"))
    overlay.setFont("PlateCaption",size)
    overlay.drawString(margin,caption_y,f"图 {fig}    {title}")
    overlay.setFont("PlateNumber",min(24,max(15,width*.016)))
    overlay.drawRightString(width-margin,13,str(printed_page))
    overlay.showPage()
    overlay.save()
    buffer.seek(0)
    composed = PageObject.create_blank_page(width=width,height=height+band)
    composed.merge_transformed_page(page, Transformation().translate(0,band))
    writer = PdfWriter()
    composed = writer.add_page(composed)
    composed.merge_page(PdfReader(buffer).pages[0])
    writer.write(target)
    if is_erd:
        erd.add_page(composed)
    print(fig, printed_page, name)
assert len(erd.pages) == 10
erd.add_metadata({"/Title":"ADC Nexus · 实施关系数据图"})
erd.write(report.parent/"ADC_Nexus_现行关系数据图_原尺寸矢量.pdf")
