
"""Align sequence operation signatures in report plates and their editable sources."""
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path
import re
from tempfile import TemporaryDirectory
from xml.etree import ElementTree

import pymupdf
from PIL import Image

from render_state_diagrams import MODEL_OUT, OUT, renderer, save_vector_pdf
from polish_sequence_symbols import SEQUENCE_LABELS

REPORT = Path(__file__).resolve().parent
EVIDENCE = REPORT.parent / "校核记录"
SIGNATURE = re.compile(r"(?:\([^()]*\)|（[^（）]*）)$")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def operation_notation(text):
    assert text.strip(), "Empty operation name"
    return text if SIGNATURE.search(text.rstrip()) else text.rstrip() + "()"


def scene_labels(ops):
    """Read the role and arrow shape together, including self-calls."""
    out = []
    for index, op in enumerate(ops):
        if op.get("role") != "message-label":
            continue
        arrow = ops[index - 1]
        assert arrow["type"] == "line" and arrow["arrow"] in ("filled", "open"), op
        out.append((index, op, bool(arrow["dash"])))
    return out


def replace_pdf_labels(path, scene, changes, title, scale, offset):
    """Replace only affected label glyphs on the existing vector plate."""
    if not changes:
        return
    with TemporaryDirectory() as scratch, pymupdf.open(path) as doc:
        page = doc[0]
        spans = [span for block in page.get_text("dict")["blocks"] if "lines" in block
                 for line in block["lines"] for span in line["spans"]]
        x0, y0 = offset
        consumed = set()
        for old, _ in changes:
            for number, label in enumerate(old["text"].split("\n")):
                y = y0 + scale * (old["y"] + number * old["size"] * 1.25)
                x = x0 + scale * old["x"]
                eligible = []
                for i, span in enumerate(spans):
                    left, _, right, _ = span["bbox"]
                    anchor = {"middle": (left + right) / 2, "start": left, "end": right}[old["anchor"]]
                    if (i not in consumed and span["text"].strip() == label.strip()
                            and abs(anchor - x) <= max(16, scale * old["size"])
                            and abs(span["origin"][1] - y) <= scale * (old["size"] + 5)
                            and abs(span["size"] - old["size"] * scale) < .5):
                        eligible.append((abs(span["origin"][1] - y), i, span))
                assert eligible, (path.name, old["text"], x, y)
                _, i, span = min(eligible)
                consumed.add(i)
                # A thin interior slice intersects every glyph of this label and
                # leaves the surrounding arrows, frame and other labels intact.
                left, top, right, bottom = span["bbox"]
                mid = (top + bottom) / 2
                page.add_redact_annot((left - .15, mid - 1, right + .15, mid + 1), fill=False)
        before = Counter("".join(page.get_text().split()))
        page.apply_redactions(images=0, graphics=0, text=0)
        removed = before - Counter("".join(page.get_text().split()))
        expected = Counter("".join("".join(old["text"].split()) for old, _ in changes))
        assert removed == expected, (path, removed - expected, expected - removed)
        layer = renderer.Scene(scene.w, scene.h, scene.style)
        layer.ops = [new for _, new in changes]
        overlay = Path(scratch) / "labels.pdf"
        save_vector_pdf(layer, overlay, title)
        with pymupdf.open(overlay) as labels:
            page.show_pdf_page(pymupdf.Rect(x0, y0, x0 + scale * scene.w, y0 + scale * scene.h),
                               labels, 0, overlay=True)
        expected = before - removed + Counter("".join("".join(new["text"].split()) for _, new in changes))
        assert Counter("".join(page.get_text().split())) == expected, path.name
        new_pdf = doc.tobytes(garbage=3, deflate=True)
    path.write_bytes(new_pdf)


def main():
    tex = "\n".join(path.read_text(encoding="utf-8") for path in sorted(REPORT.glob("*.tex")))
    source = re.findall(r"\\(fig\w+)\{([^}]+)\}\{([^}]+)\}\{(fig:[^}]+)\}", tex)
    jobs = {stem: (macro, caption, label) for macro, stem, caption, label in source
            if label.startswith(SEQUENCE_LABELS)}
    symbols = read_json(EVIDENCE / "序列图符号核验.json")
    assert set(jobs) == {stem for stem, item in symbols.items() if item["in_report"]}
    for name in sorted(set(symbols) - set(jobs)):
        jobs[name] = (None, name, None)
    proof = {}
    for name, (macro, title, label) in jobs.items():
        scene_path = OUT / f"{name}.scene.json"
        data = read_json(scene_path)
        scene = renderer.Scene(data["width"], data["height"], renderer.PROFILES["mayuyang"])
        scene.ops = data["ops"]
        labels = scene_labels(scene.ops)
        changes = []
        models = sorted(MODEL_OUT.rglob(f"{name}.json"))
        if models:
            primary = read_json(models[-1])
            assert [(m["label"], m.get("kind") == "return") for m in primary["messages"]] == [
                (op["text"], reply) for _, op, reply in labels], name
        else:
            assert macro == "figoverview", name

        for _, op, reply in labels:
            if reply:
                continue
            text = operation_notation(op["text"])
            if text != op["text"]:
                old = dict(op)
                op["text"] = text
                changes.append((old, op))
        proof[name] = dict(figure_label=label, operations=sum(not reply for _, _, reply in labels),
                           replies=sum(reply for _, _, reply in labels), added_signatures=len(changes))

        if not changes:
            continue

        audit_path = OUT / f"{name}.audit.json"
        previous_audit = read_json(audit_path)
        scene.protected_segments = previous_audit.get("protected_segments", [])
        before_scene = renderer.Scene(scene.w, scene.h, scene.style)
        by_identity = {id(new): old for old, new in changes}
        before_scene.ops = [by_identity.get(id(op), op) for op in scene.ops]
        before_scene.protected_segments = scene.protected_segments
        previous_issues = before_scene.audit()["issues"]
        result = scene.audit()
        stripped = {new["text"]: old["text"] for old, new in changes}
        def issue_key(issue):
            issue = deepcopy(issue)
            if issue.get("text") in stripped:
                issue["text"] = stripped[issue["text"]]
            if "texts" in issue:
                issue["texts"] = [stripped.get(text, text) for text in issue["texts"]]
            return (issue["type"], issue.get("text"), tuple(issue.get("texts", [])), issue.get("segment"))
        assert not (Counter(issue_key(issue) for issue in result["issues"]) -
                    Counter(issue_key(issue) for issue in previous_issues)), (name, result["issues"])
        previous_audit["issues"] = result["issues"]
        previous_audit["text_bounds"] = result["text_bounds"]
        write_json(audit_path, previous_audit)
        write_json(scene_path, data)

        png = OUT / f"{name}.png"
        with Image.open(png) as previous_png:
            original_size = previous_png.size
        scale = round(original_size[0] / scene.w)
        renderer.save_png(scene, png, scale=scale)
        with Image.open(png) as new_png:
            assert new_png.size == original_size, (name, original_size, new_png.size)
        renderer.save_svg(scene, OUT / f"{name}.svg")
        renderer.save_drawio(scene, OUT / f"{name}.drawio")
        for ext in ("svg", "drawio"):
            ElementTree.parse(OUT / f"{name}.{ext}")

        for model_path in models:
            model = read_json(model_path)
            for message in model["messages"]:
                if message.get("kind") != "return":
                    message["label"] = operation_notation(message["label"])
            write_json(model_path, model)
        if models:
            renderer.save_plantuml(model, OUT / f"{name}.puml")

        if macro == "figoverview":
            for folder in ("overview_original_pages", "overview_pages"):
                replace_pdf_labels(OUT / folder / f"{name}.pdf", scene, changes, title, .75, (0, 0))
        elif macro == "figanalysisplate":
            body = OUT / f"{name}_body.pdf"
            if body.exists():
                replace_pdf_labels(body, scene, changes, title, 1, (0, 0))
                replace_pdf_labels(OUT / "analysis_pages" / f"{name}.pdf", scene, changes, title, 1, (0, 0))
            else:
                for folder in ("analysis_original_pages", "analysis_pages"):
                    replace_pdf_labels(OUT / folder / f"{name}.pdf", scene, changes, title, .75, (44, 36))
        elif macro == "figclassvector":
            replace_pdf_labels(OUT / f"{name}_vector.pdf", scene, changes, title, 1, (0, 0))

    write_json(EVIDENCE / "序列图消息标注核验.json", proof)
    print(f"{len(proof)} sequence diagrams; {sum(x['added_signatures'] for x in proof.values())} added signatures")


if __name__ == "__main__":
    main()

