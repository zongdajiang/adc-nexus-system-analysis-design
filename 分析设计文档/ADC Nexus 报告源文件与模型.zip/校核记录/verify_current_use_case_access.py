"""Recheck the release JAR's use-case read paths in a disposable demo instance."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import secrets
import socket
import subprocess
from tempfile import TemporaryDirectory
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen

evidence = Path(__file__).resolve().parent
app = evidence.parents[2] / "adc-nexus-jdbc"
jar = app / "target/adc-nexus.jar"
proof = {"jar_sha256": sha256(jar.read_bytes()).hexdigest(), "requests": []}
calendar = {"CLINIC_MANAGER", "DENTIST", "FRONT_DESK", "CASHIER", "HQ_OPERATIONS"}
recall = calendar - {"CASHIER"}
cash = {"CLINIC_MANAGER", "CASHIER", "HQ_FINANCE"}


def check_alignment(get):
    """Confirm report distinctions with fresh data rather than slide examples."""
    dentist = get("DENTIST", "/auth/session")["principal"]["dentist_id"]
    today = get("CLINIC_MANAGER", "/bootstrap")["today"]
    day = f"?from={today}&to={today}"
    calendar = get("DENTIST", "/appointments"+day)
    visits = get("DENTIST", "/visits")
    assert dentist and {dentist} < {row["dentist_id"] for row in calendar}
    assert visits and all(row["dentist_id"] == dentist for row in visits)

    patient = get("CLINIC_MANAGER", "/patients")["items"][0]["id"]
    dossier = get("CLINIC_MANAGER", "/patients/"+patient)
    cashier_dossier = get("CASHIER", "/patients/"+patient)
    assert {"appointments", "visits", "history", "allergies"} <= set(dossier)
    assert not ({"invoices", "payments", "refunds"} & set(dossier))
    assert cashier_dossier["clinical_details_available"] is False
    assert not any(cashier_dossier[key] for key in ("history", "allergies"))
    summary = cashier_dossier["patient"]
    assert "email" not in summary and "government_id_last4" not in summary
    assert not summary.get("phone") or "*" in summary["phone"]
    assert isinstance(get("CASHIER", "/finance/invoices"), list)

    appts = get("CLINIC_MANAGER", "/appointments"+day)
    metrics = get("CLINIC_MANAGER", "/analytics"+day)
    cancels = sum(row["status"] == "CANCELLED" for row in appts)
    missed = sum(row["status"] == "NO_SHOW" for row in appts)
    assert len(appts) == metrics["appointments"] and cancels == metrics["cancellations"]
    assert missed == metrics["no_shows"]
    assert 0 < cancels < len(appts) and missed > 0
    assert math.isclose(metrics["cancellation_rate"], cancels/len(appts))
    assert math.isclose(metrics["no_show_rate"], missed/(len(appts)-cancels))

    period = get("HQ_FINANCE", "/finance/periods")
    assert period["periods"] and {"period_summaries", "results", "pools"} <= set(period)
    return [
        "Clinician calendar reads authorized clinic appointments, while clinical encounters are limited to that clinician",
        "Patient profile and billing use separate endpoints; cashier clinical data and identifiers are restricted",
        "Scheduled service, cancellation and no-show indicators match the daily appointment list and denominators",
        "Financial periods expose period summaries separately from approved snapshots",
    ]

with TemporaryDirectory(prefix="adc-use-case-") as folder:
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    admin = secrets.token_urlsafe(24)
    env = {**os.environ, "APP_ENV": "DEMO", "DEMO_MODE": "true", "SEED_DATA": "true",
           "DEMO_SCENARIO_MODE": "daily", "ADMIN_PASSWORD": admin,
           "PORT": str(port), "BIND_ADDRESS": "127.0.0.1", "DATA_DIR": folder}
    for name in ("DATABASE_URL", "ADC_TEST_NOW", "ADC_TEST_NOW_FILE"):
        env.pop(name, None)

    def call(path, body=None, auth=None):
        header = {"Content-Type": "application/json"}
        header.update(auth or {})
        request = Request(base+"/api"+path, json.dumps(body).encode() if body is not None else None, header)
        try:
            with urlopen(request, timeout=5) as response:
                return response.status, json.load(response), response.headers
        except HTTPError as error:
            return error.code, json.load(error), error.headers

    def verify(role, path, expected, body=None, auth=None):
        status, data, headers = call(path, body, auth)
        assert status == expected, (role, path, status, expected)
        proof["requests"].append({"role": role, "path": path.split("?")[0], "status": status,
                                   "method": "GET" if body is None else "POST"})
        return data, headers

    with (Path(folder)/"startup.log").open("wb") as log:
        service = subprocess.Popen(
            [env.get("ADC_JAVA", "java"), "-Dfile.encoding=UTF-8", "-jar", "target/adc-nexus.jar"],
            cwd=app, env=env, stdout=log, stderr=log)
        try:
            for _ in range(180):
                assert service.poll() is None, "Demo did not start"
                try:
                    if call("/health")[1]["ok"]:
                        break
                except OSError:
                    time.sleep(.2)
            else:
                raise RuntimeError("Demo readiness timed out")
            config, _ = verify("PUBLIC", "/auth/config", 200)
            assert not config["sms"] and not config["email"]
            credentials = [(row["role"], row["username"], config["demo_password"])
                           for row in config["demo_accounts"]]
            assert {row[0] for row in credentials} == calendar | {"HQ_FINANCE"}
            credentials.append(("ADMIN", "owner", admin))
            sessions, resource_rows = {}, {}
            for role, user, password in credentials:
                data, headers = verify(role, "/auth/login", 200, {"username": user, "password": password})
                auth = {"Cookie": headers["Set-Cookie"].split(";", 1)[0], "X-CSRF-Token": data["csrf"]}
                sessions[role] = auth
                overview, _ = verify(role, "/dashboard", 200, auth=auth)
                assert bool(overview.get("finance")) == (role in cash)
                assert role in calendar or not overview["today_agenda"]
                resources, _ = verify(role, "/resources", 200, auth=auth)
                resource_rows[role] = {row["id"] for row in resources["clinics"]}
                assert resources["hours"] and resources["chairs"]
                if role in {"CASHIER", "HQ_FINANCE", "ADMIN"}:
                    assert resources["credentials"] == []
                verify(role, "/waitlist", 200 if role in calendar else 403, auth=auth)
                followups, _ = verify(role, "/followups", 200 if role in recall else 403, auth=auth)
                if role in recall and followups["items"]:
                    record = followups["items"][0]["id"]
                    detail, _ = verify(role, "/followups/"+record, 200, auth=auth)
                    assert role in {"CLINIC_MANAGER", "FRONT_DESK"} or detail["phone"] is None
            other_clinic = min(resource_rows["HQ_OPERATIONS"] - resource_rows["FRONT_DESK"])
            verify("FRONT_DESK", "/resources?clinic_id="+other_clinic, 403, auth=sessions["FRONT_DESK"])
            verify("FRONT_DESK", "/dashboard?from=2026-11-02&to=2026-11-01", 422,
                   auth=sessions["FRONT_DESK"])
            for role in ("FRONT_DESK", "HQ_FINANCE", "ADMIN"):
                verify(role, "/resources", 403, {"action": "clinic_profile"}, sessions[role])
            for endpoint, action in (("/waitlist", "add"), ("/followups", "contact")):
                verify("HQ_OPERATIONS", endpoint, 403, {"action": action}, sessions["HQ_OPERATIONS"])
            def get_for_report(role, path):
                status, data, _ = call(path, auth=sessions[role])
                assert status == 200, (role, path, status)
                return data
            proof["report_alignment"] = check_alignment(get_for_report)
        finally:
            service.terminate()
            service.wait(timeout=15)
proof.update(passed=True, demo_delivery_channels_enabled=False)
(evidence/"use-case-access.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(f"PASS {len(proof['requests'])} role requests and {len(proof['report_alignment'])} report alignment checks")
