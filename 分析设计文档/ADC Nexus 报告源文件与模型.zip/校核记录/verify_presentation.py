"""Verify the submission form and retained use-case relations."""
from hashlib import sha256
import csv
import json
from pathlib import Path
import re

from pypdf import PdfReader
import pypdfium2 as pdfium

evidence = Path(__file__).resolve().parent
edition = evidence.parent
baseline = edition.parent / "ADC_Nexus_系统分析与设计_终稿_20261123"


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def membership(model):
    names = {"牙医": "负责医师", "系统管理员": "权限管理员", "内部员工": "员工"}
    actors = {person["id"]: person["label"] for person in model["actors"]}
    return {(case["label"][:5], names.get(actors[aid], actors[aid]))
            for case in model["usecases"] for aid in case["actors"]}


figure_results = {}
models = Path("models/uml/20261123")
overview = models / "08_员工网页用例全景.json"
previous = membership(read_json(baseline / overview))
actual = set()
initial_edges = 0
staff_diagrams = 0
business_cases = set()
for model_path in (edition / models).glob("*.json"):
    diagram = read_json(model_path)
    if diagram["type"] != "usecase":
        continue
    name = model_path.stem
    checks = read_json(edition / "assets/uml" / (name + ".audit.json"))
    scene = read_json(edition / "assets/uml" / (name + ".scene.json"))
    links = diagram["associations"]
    assert not checks["issues"] and links == checks["associations"] and links, name
    assert len({(line["source"], line["target"]) for line in links}) == len(links), name
    shapes = {actor["id"] for actor in diagram["actors"]}
    use_cases = {case["id"] for case in diagram["usecases"]}
    assert len([op for op in scene["ops"] if op.get("arrow") == "open"]) == len(links)
    for link in links:
        left, right = link["source"], link["target"]
        if link["role"] == "supporting":
            assert (left, right) in {("uc15a", "wechat"), ("uc16", "delivery"),
                                     ("uc17a", "delivery"), ("uc17b", "delivery")}
            assert left in use_cases and right in shapes
        else:
            assert left in shapes and right in use_cases, link
    if diagram["system"] == "ADC Nexus 员工端":
        actual |= membership(diagram)
        staff_diagrams += 1
    if name.startswith(("01_", "01B_", "01C_")):
        business_cases |= {case["label"].split("\n", 1)[0] for case in diagram["usecases"]}
    if "uc20a" in use_cases:
        assert {link["source"] for link in links if link["target"] == "uc20a"} == {"dentist"}
        assert {link["source"] for link in links if link["target"] == "uc20b"} == {"front", "manager"}
    if "uc21a" in use_cases:
        assert {link["source"] for link in links if link["target"] == "uc21a"} == {"ops"}
        assert {link["source"] for link in links if link["target"] == "uc21b"} == {"ops", "finance"}
    figure_results[name] = len(links)
assert business_cases == {f"BUC-{n:02d}" for n in range(1, 9)}
assert staff_diagrams == 11
assert {pair for pair in actual if int(pair[0][-2:]) <= 21 and pair[1] != "验证码投递服务"} == previous
permissions = {22: "catalog.manage", 23: "clinic.manage", 24: "audit.read", 25: "expense.manage",
               26: "period.read", 27: "clinical.read", 28: "patient.read", 29: "finance.read", 30: "appointment.read"}
role_labels = {"CLINIC_MANAGER": "诊所经理", "DENTIST": "负责医师", "FRONT_DESK": "前台接待",
               "CASHIER": "收费员", "HQ_OPERATIONS": "总部运营", "HQ_FINANCE": "总部财务", "ADMIN": "权限管理员"}
with (evidence / "岗位权限码.csv").open(encoding="utf-8-sig", newline="") as file:
    grants = [(role_labels[row["实际角色码"].removeprefix("JDBC_")], row["权限码"])
              for row in csv.DictReader(file)]
for n, permission in permissions.items():
    case = f"UC-{n:02d}"
    assert {name for label, name in actual if label == case} == {
        name for name, grant in grants if grant == permission}, case
routes = read_json(evidence / "review-browser.json")["pages"]
for code, route, separate_view in ((31, "#/resources", set()), (32, "#/waitlist", set()),
                                    (33, "#/dashboard", {"CLINIC_MANAGER"})):
    assert {name for label, name in actual if label == f"UC-{code}"} == {
        role_labels[page["role"]] for page in routes
        if page["route"] == route and page["role"] not in separate_view}, code
for path in (edition / "models/uml").glob("*.state.json"):
    diagram = read_json(path)
    for link in diagram.get("transitions", []):
        if link.get("source") == "initial":
            assert not any(link.get(field) for field in ("trigger", "guard", "display")), path.name
            initial_edges += 1
assert initial_edges == 5

tables = edition / "数据设计"
data_files = [path for path in tables.rglob("*") if path.is_file()]
for path in data_files:
    previous = baseline / path.relative_to(edition)
    assert sha256(path.read_bytes()).digest() == sha256(previous.read_bytes()).digest(), path.name

report = edition / "report/main.tex"
text = report.read_text(encoding="utf-8")
previous = (baseline / "report/main.tex").read_text(encoding="utf-8")
assert set(re.findall(r"\\label\{([\w:-]+)\}", previous)) <= set(re.findall(r"\\label\{([\w:-]+)\}", text))
for original, extension in [("use_case_specifications.tex", "extended_case_specifications.tex"),
                            ("implementation_trace.tex", "extended_case_trace.tex")]:
    current = "\n".join((report.parent / name).read_text(encoding="utf-8")
                        for name in (original, extension))
    assert {f"UC-{i:02d}" for i in range(1, 31)} <= set(re.findall(r"UC-\d+", current))

pdf = edition / "report/main.pdf"
with pdfium.PdfDocument(pdf) as document:
    assert 110 <= len(document)
    cover, abstract, contents, first_section = [
        re.sub(r"\s+", "", document[i].get_textpage().get_text_range()) for i in range(4)
    ]
    assert all(value in cover for value in ("姓名", "蒋宗达", "班级", "信管T2401", "810224025", "指导教师", "毕文杰"))
    assert "学生姓名" not in cover
    assert "精修" not in cover and "日期" not in cover and not re.search(r"\d{4}年", cover)
    assert "摘要" in abstract and "患者小程序" in abstract
    assert "目录" in contents and "系统实现与验收" in contents and "参考文献" in contents
    assert "核查索引" not in contents
    assert "项目背景与愿景" in first_section
    last = document[len(document)-1].get_textpage().get_text_range()
    assert "[12]" in last
    forbidden = re.compile(
        r"\b(?:1\.9\.0(?:-rc1)?|0\.4(?:-review)?|2\.5\.1|20261121-settings|"
        r"Java\s+21|PostgreSQL\s+18)\b|/?patient\s*/v\d+|"
        r"\.(?:jar|json|py)\b|UML 规范精修版|核查索引",
        re.IGNORECASE,
    )
    for index, page in enumerate(document, start=1):
        found = forbidden.search(page.get_textpage().get_text_range())
        assert not found, (index, found.group())
    pages = len(document)

pdf_reader = PdfReader(pdf)
targets = set()
for ref in pdf_reader.pages[2]["/Annots"]:
    annotation = ref.get_object()
    action = annotation.get("/A")
    if annotation.get("/Subtype") == "/Link" and action and action.get("/S") == "/GoTo":
        targets.add(action["/D"])
assert len(targets) == 10, targets
assert targets <= pdf_reader.named_destinations.keys()

proof = {"pdf_pages": pages, "pdf_sha256": sha256(pdf.read_bytes()).hexdigest(),
         "instructor": "毕文杰", "standard_contents_link_count": len(targets),
         "publication_identifiers": "No internal release numbers or file names in extractable PDF text",
         "use_case_figures": figure_results, "staff_role_use_case_pairs": len(actual),
         "business_use_cases": len(business_cases), "additional_permission_verified_cases": len(permissions),
         "unlabelled_initial_transitions": initial_edges, "unchanged_relational_design_file_count": len(data_files)}
(evidence / "presentation-qa.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2)+"\n",
                                                encoding="utf-8")
print(json.dumps(proof, ensure_ascii=False))
