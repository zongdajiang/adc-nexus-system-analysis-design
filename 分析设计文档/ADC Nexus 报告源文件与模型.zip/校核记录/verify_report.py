"""Verify the report against read-only runtime metadata, evidence and rendered PDF."""
from collections import Counter
from contextlib import closing
import csv
import hashlib
import json
from pathlib import Path
import re
import sqlite3
from xml.etree import ElementTree
from zipfile import ZipFile

from PIL import Image, ImageChops, ImageDraw
from pypdf import PdfReader
import pypdfium2 as pdfium

evidence = Path(__file__).resolve().parent
edition = evidence.parent
workspace = edition.parents[1]
source = workspace / "adc-nexus-jdbc"
delivery = workspace / "deliverables/ADC_Nexus_Release_Readiness_20261120/runtime"
doc_files = edition / "report"
pdf_file = doc_files / "main.pdf"
aux = (doc_files / "main.aux").read_text(encoding="utf-8")
data_design = edition / "数据设计"


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


fingerprint = sha256(delivery / "target/adc-nexus.jar")
current_jar = source / "target/adc-nexus.jar"
current_fingerprint = sha256(current_jar)
with ZipFile(delivery / "target/adc-nexus.jar") as archived, ZipFile(current_jar) as current:
    def business_entries(container):
        return {name: container.read(name) for name in container.namelist()
                if name.startswith(("cn/adcnexus/", "db/")) and not name.endswith("/")}
    assert business_entries(archived) == business_entries(current)
current_access = read_json(evidence / "use-case-access.json")
assert current_access["passed"] and current_access["jar_sha256"] == current_fingerprint
assert len(current_access["requests"]) == 47 and len(current_access["report_alignment"]) == 4
fresh_regressions = read_json(evidence / "现行业务回归.json")
assert fresh_regressions["passed"] and fresh_regressions["jar_sha256"] == current_fingerprint
assert len(fresh_regressions["suites"]) == 6
fresh_browser = read_json(evidence / "现行浏览器复验.json")
assert len(fresh_browser["rows"]) == 410
assert all(row["rootOverflow"] <= 2 and not row["controlsOutside"] and not row["clipped"] and
           not row["shownError"] and row["viewport"] == row["width"] for row in fresh_browser["rows"])
assert len({(row["role"], row["route"]) for row in fresh_browser["rows"]
            if row["role"] != "PUBLIC" and row["route"].startswith("#/")}) == 49
sequence_symbols = read_json(evidence / "序列图符号核验.json")
assert sum(record["in_report"] for record in sequence_symbols.values()) == 26
analysis_heads = [record for record in sequence_symbols.values() if "entity_style_heads" in record]
assert len(analysis_heads) == 14
assert sum(record["entity_style_heads"] for record in analysis_heads) == 26
assert all(record["entity_diagonal_marks"] == record["entity_style_heads"] for record in analysis_heads)
assert all(record["boundary_control_without_baseline"] == 2 for record in analysis_heads)
publication = workspace / "deliverables/ADC Nexus 发布交付"
for package, location in (("ADC Nexus 服务器部署包.zip", "adc-nexus.jar"),
                          ("ADC Nexus 本地试用包.zip", "runtime/target/adc-nexus.jar")):
    with ZipFile(publication / package) as archive:
        assert hashlib.sha256(archive.read(location)).hexdigest() == current_fingerprint
running_sqlite = read_json(evidence / "regressions-sqlite.json")
assert running_sqlite["passed"] and running_sqlite["jar_sha256"] == fingerprint
assert len(running_sqlite["suites"]) == 6 and all(item["passed"] for item in running_sqlite["suites"])
expansion = read_json(evidence / "uc21-expansion.json")
assert expansion["passed"] and expansion["build_sha256"] == fingerprint and len(expansion["checks"]) == 7
for filename, count in [("acceptance-results.json", 178), ("acceptance-postgres.json", 176)]:
    run = read_json(evidence / filename)
    assert (run["passed"], run["tests"], run["artifact"]["sha256"]) == (True, count, fingerprint)

with closing(sqlite3.connect((delivery / "data/adc-nexus.sqlite").as_uri() + "?mode=ro", uri=True)) as live, \
        closing(sqlite3.connect(":memory:")) as replay:
    replay.executescript((data_design / "sqlite-schema.sql").read_text(encoding="utf-8-sig"))
    statement = "SELECT type,name,sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY 1,2"
    objects = live.execute(statement).fetchall()
    assert objects == replay.execute(statement).fetchall()
    table_names = [name for kind, name, _ in objects if kind == "table"]
    physical_fields = {(table, field[1]): field for table in table_names
                       for field in live.execute("SELECT * FROM pragma_table_info(?)", (table,))}
    fk_count = sum(len(live.execute("SELECT * FROM pragma_foreign_key_list(?)", (table,)).fetchall())
                   for table in table_names)
    index_count = sum(live.execute("SELECT count(*) FROM pragma_index_list(?) WHERE origin<>'pk'", (table,)).fetchone()[0]
                      for table in table_names)
    assert not live.execute("PRAGMA foreign_key_check").fetchall()
    migrations = [row[0] for row in live.execute("SELECT version FROM schema_migrations ORDER BY version")]
    assert migrations == [f"{i:03d}" for i in range(1, 11)]
    db_grants = set(live.execute("SELECT r.code,p.code FROM roles r JOIN role_permissions rp ON r.id=rp.role_id"
                                 " JOIN permissions p ON p.id=rp.permission_id").fetchall())

assert (len(table_names), len(physical_fields), fk_count, index_count) == (71, 820, 146, 139)
with (data_design / "字段字典.csv").open(encoding="utf-8-sig", newline="") as opened:
    dictionary = {(row["表"], row["字段"]): row for row in csv.DictReader(opened)}
assert dictionary.keys() == physical_fields.keys()
for key, field in physical_fields.items():
    assert dictionary[key]["类型"] == field[2], key
selected = [line.split("|") for line in (edition / "models/dictionary_scope.txt").read_text(
    encoding="utf-8").splitlines() if line.startswith("table|")]
selected_fields = {(row[1], value.split("=", 1)[0]) for row in selected for value in row[3:]}
assert selected_fields <= physical_fields.keys()

cases = [row.split("|") for row in (edition / "models/use_cases.txt").read_text(encoding="utf8").splitlines()
         if row.startswith("UC-")]
identifiers = {f"UC-{n:02d}" for n in range(1, 34)}
assert {row[0] for row in cases} == identifiers
main = (doc_files / "main.tex").read_text(encoding="utf8")
specs = "\n".join((doc_files / f).read_text(encoding="utf8")
                  for f in ("use_case_specifications.tex", "extended_case_specifications.tex"))
trace = "\n".join((doc_files / f).read_text(encoding="utf8")
                  for f in ("implementation_trace.tex", "extended_case_trace.tex"))
catalogue = main + "\n" + (doc_files / "extended_case_catalogue.tex").read_text(encoding="utf8")
assert identifiers == set(re.findall(r"^(UC-\d+)\s*&", catalogue, re.M))
assert identifiers == set(re.findall(r"^(UC-\d+)\s*&", trace, re.M))
assert identifiers == set(re.findall(r"\\label\{uc:(UC-\d+)\}", specs))
assert identifiers == set(re.findall(r"\\newlabel\{uc:(UC-\d+)\}", aux))
main_java = (source / "src/main/java/cn/adcnexus/Main.java").read_text(encoding="utf8")
service_routes = set(re.findall(r'"/api/([a-z][\w/-]*)"', main_java))
checked_paths = {}
for case_id, *_, proof in cases:
    paths = re.findall(r"(?<![A-Za-z0-9}])/[a-z][a-z0-9_/\-]*(?:\{[A-Za-z_]+\})?", proof.split("；", 1)[0])
    assert paths, case_id
    for path in paths:
        stem = path[1:]
        if "{" in stem:
            stem = stem.split("{", 1)[0]
        if case_id != "UC-15":
            assert stem in service_routes, (case_id, stem)
    checked_paths[case_id] = paths

uml = edition / "models/uml/20261123"
overview = read_json(uml / "08_员工网页用例全景.json")
catalogue_members = [case for package in overview["packages"] for case in package["member_use_cases"]]
assert overview["type"] == "package" and len(overview["packages"]) == 4
assert set(catalogue_members) == identifiers - {"UC-15"}
assert len(catalogue_members) == len(set(catalogue_members))
assets = edition / "assets/uml"
package_source = (assets / "08_员工网页用例全景.puml").read_text(encoding="utf8")
assert set(re.findall(r'usecase "(UC-\d+)', package_source)) == set(catalogue_members)
assert not re.search(r"<<(?:import|access|merge)>>", package_source)
diagrams = [model.stem for model in sorted(uml.glob("*.json"))]
diagrams += ["14_状态机_预约", "15_状态机_临床就诊", "16_状态机_发票", "16B_状态机_退款",
             "39_状态机_候补邀请", "40_状态机_复诊建议", "12_领域类图_患者与预约"]
for name in diagrams:
    for ext in [".drawio", ".svg"]:
        ElementTree.parse(assets / f"{name}{ext}")
    with Image.open(assets / f"{name}.png") as png:
        png.verify()
    assert not read_json(assets / f"{name}.audit.json")["issues"], name
contract = read_json(evidence / "03_接口契约.json")
assert contract["status"] == "planned" and contract["useCase"] == "UC-15"
assert contract["basePath"] == "/api/patient/v1" and len(contract["routes"]) == 16
assert {p for r in contract["routes"] for p in r["pages"]} == {f"MP-{i:02d}" for i in range(1, 13)}
patient = read_json(evidence / "patient-prototype.json")
assert patient["passed"] and patient["tests"] == 17

browser = read_json(evidence / "review-browser.json")
assert browser["passed"] and browser["authorized_pages"] == 49
assert all(page["mobile_390px_fits"] for page in browser["pages"])
roles = {"CLINIC_MANAGER": "诊所经理", "DENTIST": "医师", "FRONT_DESK": "前台接待",
         "CASHIER": "收费员", "HQ_OPERATIONS": "总部运营", "HQ_FINANCE": "总部财务", "ADMIN": "权限管理员"}
routes = (doc_files / "role_routes.tex").read_text(encoding="utf-8")
permission_table = (doc_files / "permission_snapshot.tex").read_text(encoding="utf-8")
with (evidence / "岗位权限码.csv").open(encoding="utf-8-sig", newline="") as opened:
    exported_grants = {(row["实际角色码"], row["权限码"]) for row in csv.DictReader(opened)}
actual_grants = {entry for entry in db_grants if entry[0][5:] in roles and entry[0].startswith("JDBC_")}
assert exported_grants == actual_grants
for role, name in roles.items():
    row = next(line for line in routes.splitlines() if line.startswith(name + " &"))
    permitted = {page["route"] for page in browser["pages"] if page["role"] == role}
    assert permitted == set(re.findall(r"\\path\{(\#/[^}]+)\}", row)), (role, permitted)
    line = next(line for line in permission_table.splitlines() if line.startswith(name + r"\newline"))
    assert set(re.findall(r"\\path\{([a-z][^}]+)\}", line)) == {
        grant for role_code, grant in actual_grants if role_code == "JDBC_"+role
    }
assert read_json(evidence / "roles-review.json")["count"] == 6
assert read_json(evidence / "operating-browser.json")["count"] == 9
entry_use_cases = {}
for route, row in re.findall(r"^\\path\{(\#/[^}]+)\}\s*&\s*([^&]+)&", routes, re.M):
    entry_use_cases[route] = sorted(set(re.findall(r"UC-\d+", row)))
    assert entry_use_cases[route] and set(entry_use_cases[route]) <= identifiers - {"UC-15"}
assert entry_use_cases.keys() == {page["route"] for page in browser["pages"]}
by_actor = {}
for path in uml.glob("*.json"):
    diagram = read_json(path)
    if diagram.get("system") != "ADC Nexus 员工端":
        continue
    actors = {actor["id"]: actor["label"] for actor in diagram["actors"]}
    for case in diagram["usecases"]:
        by_actor.setdefault(case["label"][:5], set()).update(actors[role] for role in case["actors"])
assert set(by_actor) == identifiers - {"UC-15"}
with (evidence / "岗位入口用例对照.csv").open("w", encoding="utf-8-sig", newline="") as file:
    entry_sheet = csv.writer(file)
    entry_sheet.writerow(["岗位", "实测入口", "入口相关规约", "本岗位适用规约", "范围说明"])
    for page in browser["pages"]:
        label, route = roles[page["role"]], page["route"]
        actor = "负责医师" if label == "医师" else label
        related = entry_use_cases[route]
        permitted = [case for case in related if by_actor[case] & {actor, "员工"}]
        if route == "#/clinical" and label == "诊所经理":
            permitted = [case for case in permitted if case != "UC-20"]
        note = "具体操作须复核授权范围及资源状态"
        if route == "#/dashboard" and label != "诊所经理":
            note = "工作台摘要按岗位权限显示"
        elif route == "#/resources" and not permitted:
            note = "诊所及资源资料只读"
        elif route == "#/waitlist" and label == "总部运营":
            note = "授权范围内查看候补及复诊资料"
        assert permitted, (label, route)
        entry_sheet.writerow([label, route, "、".join(related), "、".join(permitted), note])

document = pdfium.PdfDocument(pdf_file)
assert len(document) >= 110
tex_log = (doc_files / "main.log").read_text(encoding="utf-8", errors="replace")
for problem in ["Missing character:", "There were undefined references", "multiply defined",
                "Overfull \\hbox", "Overfull \\vbox"]:
    assert problem not in tex_log, problem

previews = evidence / "排版校样"
previews.mkdir(exist_ok=True)
detail_pages = {"撤销签到", "接受候补邀请的分析序列图", "候补邀请状态机", "评估候选诊所扩张方案",
                "员工端系统用例包图", "患者小程序目标系统用例图", "过敏资料字段", "实装与核验证据索引"}
detail_saved = set()
page_texts = []
for first in range(0, len(document), 16):
    sheet = Image.new("RGB", (1120, 1480), "#e6ebe8")
    marks = ImageDraw.Draw(sheet)
    for offset, number in enumerate(range(first, min(first+16, len(document)))):
        page = document[number]
        width, height = page.get_size()
        img = page.render(scale=min(260/width, 340/height)).to_pil().convert("RGB")
        assert ImageChops.difference(img, Image.new("RGB", img.size, "white")).getbbox(), number+1
        x, y = offset % 4 * 280, offset // 4 * 370
        sheet.paste(img, (x+(280-img.width)//2, y+21))
        marks.text((x+12, y+5), str(number+1), fill="#183b2f")
        text = page.get_textpage().get_text_range()
        page_texts.append(text)
        for title in detail_pages:
            if title in text and title not in detail_saved and number > 4:
                page.render(scale=min(1.6, 1500/width, 1650/height)).to_pil().save(
                    previews / f"detail-{number+1:03d}-{title}.png")
                detail_saved.add(title)
    sheet.save(previews / f"pages-{first+1:03d}-{min(first+16, len(document)):03d}.png")
assert not any("??" in page or "\ufffd" in page for page in page_texts)
native_captions = {}
for kind, name, title, label in re.findall(
        r"\\(figoverview|figanalysisplate|figerdplate)\{([^}]+)\}\{([^}]+)\}\{(fig:[^}]+)\}",
        main + (doc_files / "d_erd_overviews.tex").read_text(encoding="utf8")):
    match = re.search(r"\\newlabel\{" + re.escape(label) + r"\}\{\{(\d+)\}\{(\d+)\}", aux)
    figure_number, printed_page = map(int, match.groups())
    page = document[printed_page+2]
    width, height = page.get_size()
    footer = page.get_textpage().get_text_bounded(0, 0, width, min(110, .18*height))
    assert re.search(rf"图\s*{figure_number}\s*", footer), (label, figure_number, footer)
    assert str(printed_page) in footer.split(), (label, printed_page, footer)
    assert len(re.findall(r"图\s*\d+\s", footer)) == 1, (label, footer)
    native_captions[label] = title

figures = re.findall(r"\\newlabel\{(fig:[^}]+)\}\{\{(\d+)\}\{(\d+)\}\{([^}]*)\}", aux)
assert [int(number) for _, number, _, _ in figures] == list(range(1, 84))
figure_numbers = {label: int(number) for label, number, _, _ in figures}
checks_by_figure = [
    ("fig:business-support", "业务用例", "课程业务记法；三种责任范围、八项业务成果与执行者"),
    ("fig:to-be-quarter", "业务序列", "岗位责任、现状假设与改进流程；生命线、消息及组合片段"),
    ("fig:system-usecase-overview", "用例包", "成员包与员工端规约"),
    ("fig:uc-role-overview", "员工系统用例", "系统边界、开放箭头、规约与岗位权限映射"),
    ("fig:patient-usecases", "患者端目标用例", "目标用例、接口契约及实施范围"),
    ("fig:domain-expansion", "领域类", "类职责、关系名称、重数与连接位置；关系数据"),
    ("fig:state-followup", "状态图", "对象边界、初始伪状态、迁移与守卫；服务端规则"),
    ("fig:bce", "分析类", "预约、就诊、结算职责及依赖"),
    ("fig:seq-expansion-create", "分析序列", "调用、返回、生命线、分支及业务服务职责"),
    ("fig:data-access-sequence", "技术设计", "应用边界、部署、界面导航和持久化事务"),
    ("fig:erd-expansion", "关系数据", "原尺寸矢量图、字段及外键；实际数据库与 DDL"),
    ("fig:verified-analytics", "实施界面", "统计筛选、指标口径与实际界面"),
    ("fig:staff-demo-sequence", "员工端序列", "身份验证、授权与工作台加载"),
    ("fig:patient-booking-target", "患者端目标序列", "交互原型与目标契约"),
    ("fig:demo-periods", "界面实证", "岗位界面与应用功能；患者端为原型"),
]
with (evidence / "图版核查.csv").open("w", encoding="utf-8-sig", newline="") as file:
    sheet = csv.writer(file)
    sheet.writerow(["图号", "图题", "正文页码", "PDF 页", "图版类型", "主要核对项"])
    for label, number, page, title in figures:
        _, kind, source = next(entry for entry in checks_by_figure if int(number) <= figure_numbers[entry[0]])
        title = native_captions.get(label, title.replace(r"\relax", "").strip())
        assert re.search(rf"图\s*{number}(?!\d)", page_texts[int(page)+2]), (label, page)
        sheet.writerow([number, title, page, int(page)+3, kind, source])

outcome = {
    "baseline_build_sha256": fingerprint, "build_sha256": current_fingerprint, "pdf_sha256": sha256(pdf_file),
    "pdf_pages": len(document), "outline_sections": len(PdfReader(pdf_file).outline),
    "case_spec_to_trace_and_diagram": "32 employee use cases; UC-15 separately verified as patient target",
    "current_use_case_role_requests": len(current_access["requests"]),
    "current_report_alignment_checks": current_access["report_alignment"],
    "current_browser_layout_checks": len(fresh_browser["rows"]),
    "current_business_regressions": len(fresh_regressions["suites"]),
    "distinct_employee_routes_mapped": len(entry_use_cases),
    "case_endpoint_index": checked_paths,
    "role_route_counts_from_same_build_browser_evidence": dict(Counter(
        roles[p["role"]] for p in browser["pages"])),
    "role_permission_pairs": len(actual_grants),
    "sqlite": {"tables": len(table_names), "columns": len(physical_fields), "foreign_keys": fk_count,
               "non_pk_indexes": index_count, "ddl_objects_identical": len(objects), "migrations": migrations},
    "documented_key_tables": len(selected), "documented_key_fields": len(selected_fields),
    "strict_uml_assets": diagrams,
    "numbered_figures": len(figures),
    "patient_target": {"version": contract["contractVersion"], "pages": 12, "routes": 16,
                       "prototype_tests": 17},
    "resolved_native_plate_captions": 18,
}
(evidence / "report-qa.json").write_text(json.dumps(outcome, ensure_ascii=False, indent=2)+"\n", encoding="utf8")
print(f"PASS {len(document)} pages, {len(identifiers)} specifications, 49 role routes, "
      f"{len(selected_fields)} annotated fields, {len(diagrams)} checked model assets")
