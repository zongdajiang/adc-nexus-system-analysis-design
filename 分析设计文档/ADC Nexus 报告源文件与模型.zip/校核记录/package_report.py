"""Package the verified report sources and concise audit evidence."""
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from zipfile import ZIP_DEFLATED, ZipFile

evidence = Path(__file__).resolve().parent
edition = evidence.parent
review = json.loads((evidence / "report-qa.json").read_text(encoding="utf8"))
pdf = edition / "ADC Nexus 系统分析与设计报告.pdf"
source_pdf = edition / "report/main.pdf"
assert sha256(source_pdf.read_bytes()).hexdigest() == review["pdf_sha256"]
copyfile(source_pdf, pdf)
archive = edition / "ADC Nexus 报告源文件与模型.zip"
updated = {p.name for p in (edition / "models/uml/20261123").glob("*.json")}

with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=6) as output:
    output.write(edition / "00_阅读与复核.md", "00_阅读与复核.md")
    for path in sorted((edition / "report").glob("*.tex")):
        output.write(path, path.relative_to(edition).as_posix())
    for script in ["number_plates.py", "render_state_diagrams.py", "refine_use_case_figures.py", "draw_cover.py",
                   "extend_case_specifications.py", "draw_supplementary_models.py", "polish_sequence_symbols.py"]:
        path = edition / "report" / script
        output.write(path, path.relative_to(edition).as_posix())
    for folder in ["assets", "models", "数据设计"]:
        for path in sorted((edition / folder).rglob("*")):
            rel = path.relative_to(edition)
            if not path.is_file() or "__pycache__" in rel.parts:
                continue
            if folder == "models" and path.name in updated and "20261123" not in rel.parts:
                continue
            output.write(path, rel.as_posix())
    for path in sorted(evidence.iterdir()):
        if path.is_file() and path.suffix in (".json", ".csv", ".log", ".py") and path.name not in {
            "首次排版.log", "排版构建.log", "解包重建.log",
        }:
            output.write(path, path.relative_to(edition).as_posix())

with ZipFile(archive) as archive_reader:
    assert archive_reader.testzip() is None
    print(f"Source archive: {len(archive_reader.namelist())} files")
hashes = "".join(f"{sha256(path.read_bytes()).hexdigest()}  {path.name}\n" for path in [pdf, archive])
(edition / "SHA256SUMS.txt").write_text(hashes, encoding="utf8")
print(hashes)
