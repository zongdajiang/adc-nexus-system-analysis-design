"""Reproduce UC-21 against the delivered JAR using an isolated synthetic SQLite database."""
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
from shutil import copyfile
import socket
import sqlite3
import subprocess
import sys
from tempfile import TemporaryDirectory
import time

destination = Path(__file__).resolve().parent
workspace = destination.parents[2]
repo = workspace / "adc-nexus-jdbc"
sys.path.insert(0, str(repo / "tools"))
from verify import Client


def verify(base, database):
    operations = Client(base).demo("HQ_OPERATIONS")
    finance = Client(base).demo("HQ_FINANCE")
    manager = Client(base).demo("CLINIC_MANAGER")
    params = {
        "name": "隔离验收候选诊所", "city": "广州", "basis": "课程验收参数",
        "chairs": 6, "appointments": 1200, "average_price_fen": 85251,
        "fixed_cost_fen": 42000000, "capital_fen": 88000000, "cost_basis_points": 2875,
    }
    baseline = len(operations.request("/expansion")["scenarios"])
    with closing(sqlite3.connect(database)) as connection:
        clinic_count = connection.execute("select count(*) from clinics").fetchone()[0]
    identifier = operations.request("/expansion", params)["id"]
    outcome = finance.request("/expansion")
    scenario = next(row for row in outcome["scenarios"] if row["id"] == identifier)
    assert (scenario["status"], scenario["version"]) == ("DRAFT", 1)
    assert any(row["scenario_id"] == identifier for row in outcome["candidates"])
    source = next(row for row in outcome["assumptions"] if row["scenario_id"] == identifier)
    assert json.loads(source["value_text"]) == params
    result = next(row for row in outcome["results"] if row["scenario_id"] == identifier)
    revenue = params["appointments"] * params["average_price_fen"]
    variable = revenue * params["cost_basis_points"] // 10000
    profit = revenue - variable - params["fixed_cost_fen"]
    assert (result["projected_quarter_revenue_fen"],
            result["projected_treatment_cost_fen"],
            result["projected_net_profit_fen"],
            result["payback_months"], result["risk_level"]) == (
                revenue, variable, profit, (3 * params["capital_fen"] + profit - 1) // profit,
                "UNREVIEWED")
    loss = operations.request("/expansion", {**params, "fixed_cost_fen": revenue})["id"]
    loss_result = next(row for row in finance.request("/expansion")["results"] if row["scenario_id"] == loss)
    assert loss_result["payback_months"] == 0 and loss_result["risk_level"] == "HIGH"
    finance.request("/expansion", params, expect=403)
    manager.request("/expansion", expect=403)
    operations.request("/expansion", {**params, "chairs": 51}, expect=422)
    assert len(finance.request("/expansion")["scenarios"]) == baseline + 2
    with closing(sqlite3.connect(database)) as connection:
        assert connection.execute("select count(*) from clinics").fetchone()[0] == clinic_count
        assert not connection.execute("pragma foreign_key_check").fetchall()
    return ["总部运营创建草案，财务回读情景、假设、候选点和结果", "正收益整数分及回收期复算",
            "非正收益回收期零标记及高风险", "拒绝总部财务写入", "拒绝诊所经理读取",
            "拒绝非法参数后草案个数不变", "真实诊所表未改动，外键完整"]


def main(jar, java):
    with TemporaryDirectory(prefix="adc-uc21-") as folder:
        data = Path(folder)
        copyfile(jar, data / "application.jar")
        with socket.socket() as server:
            server.bind(("127.0.0.1", 0))
            port = server.getsockname()[1]
        env = {**os.environ, "APP_ENV": "TEST", "DEMO_MODE": "true",
               "ADC_TEST_FULL_DEMO": "true", "ADC_TEST_NOW": "2026-11-23T15:00:00",
               "DATA_DIR": str(data), "BIND_ADDRESS": "127.0.0.1", "PORT": str(port)}
        env.pop("DATABASE_URL", None)
        base = f"http://127.0.0.1:{port}"
        with (data / "stdout.log").open("w", encoding="utf-8") as log:
            process = subprocess.Popen([java, "--enable-native-access=ALL-UNNAMED", "-Dfile.encoding=UTF-8",
                                        "-jar", "application.jar"],
                                       cwd=data, env=env, stdout=log, stderr=log)
            try:
                for _ in range(60):
                    if process.poll() is not None:
                        raise RuntimeError((data / "stdout.log").read_text(encoding="utf-8", errors="replace"))
                    try:
                        Client(base).request("/health")
                        break
                    except OSError:
                        time.sleep(.5)
                else:
                    raise TimeoutError("隔离服务启动超时")
                checks = verify(base, data / "adc-nexus.sqlite")
            finally:
                process.terminate()
                process.wait(timeout=15)
    report = {"passed": True, "build_sha256": hashlib.sha256(Path(jar).read_bytes()).hexdigest(),
              "database": "isolated SQLite", "checks": checks}
    (destination / "uc21-expansion.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"PASS UC-21 · {len(checks)} checks")


if __name__ == "__main__":
    main(str(Path(sys.argv[1]).resolve()), sys.argv[2])
